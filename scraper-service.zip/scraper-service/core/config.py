import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

class Config:
    # MongoDB Configuration
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
    DB_NAME = os.getenv("DB_NAME", "cbie_knowledge_base")
    COLLECTION_NAME = os.getenv("COLLECTION_NAME", "scraped_data")

    # Reddit API Configuration (PRAW)
    REDDIT_CLIENT_ID = os.getenv("REDDIT_CLIENT_ID", "")
    REDDIT_CLIENT_SECRET = os.getenv("REDDIT_CLIENT_SECRET", "")
    REDDIT_USER_AGENT = os.getenv("REDDIT_USER_AGENT", "cbie_research_bot_v1")
    
    # Storage settings
    SAVE_TO_JSON_FALLBACK = True
    DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")

# Create data directory for JSON fallback if it doesn't exist
os.makedirs(Config.DATA_DIR, exist_ok=True)
