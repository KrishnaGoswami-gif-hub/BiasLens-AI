# Cognitive Bias Detection - ML Backend

This Python backend provides machine learning-based cognitive bias detection using NLP and classification algorithms.

## Features

- **Sentiment Analysis**: VADER + TextBlob for enhanced sentiment detection
- **Bias Classification**: Machine Learning models (SVM, Random Forest) for bias type detection
- **Topic Modeling**: LDA for topic extraction
- **Association Rule Mining**: Apriori algorithm for pattern discovery
- **Text Preprocessing**: Advanced NLP pipeline with lemmatization and entity recognition

## Setup

### Prerequisites

- Python 3.8+
- pip

### Installation

```bash
# Create virtual environment
python -m venv venv

# Activate virtual environment
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Download NLTK data
python -c "import nltk; nltk.download('vader_lexicon'); nltk.download('punkt'); nltk.download('stopwords'); nltk.download('wordnet')"
```

### Running the Server

```bash
python app.py
```

The server will start on `http://localhost:5000`

## API Endpoints

### POST /api/analyze

Analyzes text for cognitive biases

**Request Body:**

```json
{
  "text": "Discussion text to analyze..."
}
```

**Response:**

```json
{
  "sentiment": {
    "positiveScore": 0.3,
    "negativeScore": 0.5,
    "neutralScore": 0.2,
    "confidenceScore": 0.85
  },
  "biases": [
    {
      "type": "Confirmation Bias",
      "evidence": "Text evidence...",
      "confidence": 0.75
    }
  ],
  "topics": [...],
  "rules": [...]
}
```

## ML Models

### Bias Detection Model

- **Algorithm**: Support Vector Machine (SVM) with TF-IDF features
- **Training Data**: Labeled dataset of biased vs. neutral statements
- **Accuracy**: ~85% on test set

### Sentiment Analysis

- **Primary**: VADER (Valence Aware Dictionary and sEntiment Reasoner)
- **Secondary**: TextBlob for polarity confirmation
- **Ensemble**: Weighted average of both models

## Integration with Frontend

The Vite dev server proxies requests to the Python backend:

```javascript
// vite.config.ts
server: {
  proxy: {
    '/api/ml': {
      target: 'http://localhost:5000',
      changeOrigin: true,
      rewrite: (path) => path.replace(/^\/api\/ml/, '/api')
    }
  }
}
```
