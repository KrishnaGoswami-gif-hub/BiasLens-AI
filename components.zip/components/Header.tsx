import React, { useState, useEffect } from 'react';
import { Brain, Sparkles, Github } from 'lucide-react';
import { motion } from 'framer-motion';

const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.header
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, ease: 'easeOut' }}
      className={`
        sticky top-0 z-50 transition-all duration-300
        ${scrolled 
          ? 'glass shadow-lg shadow-slate-200/50' 
          : 'bg-white/50 backdrop-blur-sm'
        }
      `}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Brand */}
          <motion.div 
            className="flex items-center gap-3"
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.2 }}
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-primary-500 to-secondary-500 rounded-xl blur-lg opacity-50"></div>
              <div className="relative p-2.5 bg-gradient-to-br from-primary-600 to-secondary-600 rounded-xl shadow-lg">
                <Brain className="w-7 h-7 text-white" />
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-gradient">
                Cognitive Bias Miner
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                AI-Powered Bias Detection
              </p>
            </div>
          </motion.div>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-6">
            <motion.a
              href="#features"
              className="text-sm font-semibold text-slate-600 hover:text-primary-600 transition-colors"
              whileHover={{ y: -2 }}
              transition={{ duration: 0.2 }}
            >
              Features
            </motion.a>
            <motion.a
              href="#methodology"
              className="text-sm font-semibold text-slate-600 hover:text-primary-600 transition-colors"
              whileHover={{ y: -2 }}
              transition={{ duration: 0.2 }}
            >
              Methodology
            </motion.a>
            <motion.a
              href="#about"
              className="text-sm font-semibold text-slate-600 hover:text-primary-600 transition-colors"
              whileHover={{ y: -2 }}
              transition={{ duration: 0.2 }}
            >
              About
            </motion.a>
          </nav>

          {/* CTA Buttons */}
          <div className="flex items-center gap-3">
            <motion.a
              href="https://github.com"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-all duration-200"
              whileHover={{ scale: 1.05, rotate: 5 }}
              whileTap={{ scale: 0.95 }}
            >
              <Github className="w-5 h-5" />
            </motion.a>
            <motion.button
              className="hidden sm:flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-primary-600 to-secondary-600 text-white font-semibold text-sm shadow-lg shadow-primary-500/30 hover:shadow-xl hover:shadow-primary-500/40 transition-all duration-300"
              whileHover={{ scale: 1.05, y: -2 }}
              whileTap={{ scale: 0.95 }}
            >
              <Sparkles className="w-4 h-4" />
              Get Started
            </motion.button>
          </div>
        </div>
      </div>

      {/* Gradient Border */}
      <div className="h-px bg-gradient-to-r from-transparent via-primary-500/20 to-transparent"></div>
    </motion.header>
  );
};

export default Header;