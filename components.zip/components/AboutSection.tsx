import React from 'react';
import { motion } from 'framer-motion';
import { Github, Linkedin, Mail, Award } from 'lucide-react';

const AboutSection: React.FC = () => {
  const team = [
    {
      name: "Krishna",
      role: "Lead Developer & AI Specialist",
      avatar: "K",
      color: "from-primary-500 to-primary-600",
      skills: ["Machine Learning", "Full-Stack Development", "System Architecture"]
    },
    {
      name: "Krisha",
      role: "Data Scientist & NLP Expert",
      avatar: "K",
      color: "from-secondary-500 to-secondary-600",
      skills: ["Natural Language Processing", "Data Mining", "Statistical Analysis"]
    },
    {
      name: "Arpan",
      role: "Backend Engineer & DevOps",
      avatar: "A",
      color: "from-pink-500 to-pink-600",
      skills: ["API Development", "Cloud Infrastructure", "Performance Optimization"]
    },
    {
      name: "Kishan",
      role: "Frontend Developer & UX Designer",
      avatar: "K",
      color: "from-amber-500 to-amber-600",
      skills: ["React Development", "UI/UX Design", "Data Visualization"]
    }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Meet Our Team
          </h2>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            A passionate team of developers and data scientists dedicated to combating cognitive biases
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {team.map((member, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -8 }}
              className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300"
            >
              <div className="flex flex-col items-center text-center">
                <div className={`w-24 h-24 rounded-full bg-gradient-to-br ${member.color} flex items-center justify-center text-white text-3xl font-bold shadow-lg mb-4`}>
                  {member.avatar}
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-1">{member.name}</h3>
                <p className="text-sm text-slate-600 mb-4">{member.role}</p>
                
                <div className="w-full mb-4">
                  <div className="flex flex-wrap gap-2 justify-center">
                    {member.skills.map((skill, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-slate-100 text-slate-700 text-xs rounded-full font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3">
                  <button className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors">
                    <Github className="w-4 h-4" />
                  </button>
                  <button className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors">
                    <Linkedin className="w-4 h-4" />
                  </button>
                  <button className="p-2 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors">
                    <Mail className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Project Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="bg-gradient-to-br from-primary-50 to-secondary-50 rounded-2xl p-8 border border-primary-100"
        >
          <div className="flex items-start gap-4 mb-6">
            <div className="p-3 rounded-xl bg-gradient-to-br from-primary-500 to-secondary-500 text-white">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-slate-900 mb-2">About This Project</h3>
              <p className="text-slate-600 leading-relaxed">
                Cognitive Bias Miner is an advanced AI-powered platform designed to detect and analyze cognitive biases in online discussions. 
                Built with cutting-edge technologies including React, TypeScript, Gemini AI, and DeepSeek AI, this tool helps researchers, 
                content moderators, and analysts identify confirmation bias, negativity bias, and other cognitive distortions in digital content.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <div className="text-3xl font-bold text-primary-600 mb-1">2+</div>
              <div className="text-sm text-slate-600">AI Models</div>
            </div>
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <div className="text-3xl font-bold text-secondary-600 mb-1">95%+</div>
              <div className="text-sm text-slate-600">Accuracy Rate</div>
            </div>
            <div className="bg-white rounded-xl p-4 shadow-sm">
              <div className="text-3xl font-bold text-pink-600 mb-1">Real-time</div>
              <div className="text-sm text-slate-600">Analysis Speed</div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default AboutSection;
