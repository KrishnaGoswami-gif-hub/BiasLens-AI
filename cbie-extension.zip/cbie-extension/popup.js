document.getElementById('toggle-bias').addEventListener('click', (e) => {
    const btn = e.target;
    if (btn.innerText.includes("Pause")) {
        btn.innerText = "▶ Resume Real-Time Scans";
        btn.style.background = "#4b5563";
        // Notify content.js to pause (placeholder)
        // chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        //     chrome.tabs.sendMessage(tabs[0].id, {action: "pause"});
        // });
    } else {
        btn.innerText = "⏸ Pause Real-Time Scans";
        btn.style.background = "#3b82f6";
    }
});
