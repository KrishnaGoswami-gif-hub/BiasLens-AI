import praw
from core.config import Config

class RedditScraper:
    def __init__(self):
        self.is_configured = bool(Config.REDDIT_CLIENT_ID and Config.REDDIT_CLIENT_SECRET)
        if self.is_configured:
            try:
                self.reddit = praw.Reddit(
                    client_id=Config.REDDIT_CLIENT_ID,
                    client_secret=Config.REDDIT_CLIENT_SECRET,
                    user_agent=Config.REDDIT_USER_AGENT
                )
            except Exception as e:
                print(f"Failed to initialize Reddit client: {e}")
                self.is_configured = False
        else:
            print("⚠ Reddit API keys missing in .env. Skipping Reddit scraper.")

    def scrape_subreddit(self, subreddit_name="changemyview", limit=10):
        if not self.is_configured:
            return []
            
        print(f"Scraping top {limit} hot posts from r/{subreddit_name}...")
        results = []
        try:
            subreddit = self.reddit.subreddit(subreddit_name)
            for submission in subreddit.hot(limit=limit):
                # Skip pinned posts usually
                if submission.stickied:
                    continue
                    
                document = {
                    "source": f"reddit_r/{subreddit_name}",
                    "title": submission.title,
                    "text": submission.selftext,
                    "url": submission.url,
                    "author": str(submission.author) if submission.author else "anonymous",
                    "score": submission.score,
                    "upvote_ratio": submission.upvote_ratio,
                    "num_comments": submission.num_comments,
                    "created_utc": submission.created_utc
                }
                
                # Only keep posts that actually have text body (opinions usually do)
                if document["text"].strip():
                    results.append(document)
                    
            return results
        except Exception as e:
            print(f"Error scraping Reddit: {e}")
            return []
