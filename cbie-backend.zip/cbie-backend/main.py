from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import json
import asyncio
from ml_engine import CognitiveBiasModel

app = FastAPI(title="CBIE Real-Time Backend", version="1.0.0")

# Enable CORS for the React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize the custom ML Engine
ai_engine = CognitiveBiasModel()

class TextPayload(BaseModel):
    text: str

@app.get("/api/health")
async def health_check():
    return {"status": "ok", "service": "CBIE FastAPI Backend"}

@app.post("/api/analyze")
async def analyze_text(payload: TextPayload):
    """Standard REST endpoint for full document analysis."""
    result = ai_engine.process_realtime_text(payload.text)
    return result

@app.websocket("/ws/realtime")
async def websocket_endpoint(websocket: WebSocket):
    """
    WebSocket endpoint for the Real-Time Bias Correction Engine.
    Streams keystrokes and immediately returns bias metrics.
    """
    await websocket.accept()
    print("✓ Client connected to Real-Time Bias Engine (WebSockets)")
    try:
        while True:
            # Receive text chunk from client typing
            data = await websocket.receive_text()
            
            # If text is very short, save compute
            if len(data.strip()) < 5:
                continue

            # Process through our neuro-symbolic/ML pipeline
            analysis = ai_engine.process_realtime_text(data)

            # Send insight back instantaneously
            await websocket.send_text(json.dumps(analysis))
            
    except WebSocketDisconnect:
        print("⚠ Client disconnected from Real-Time Engine")

if __name__ == "__main__":
    import uvicorn
    print("\n" + "="*50)
    print("🚀 Starting CBIE FastAPI + WebSockets Server")
    print("   Running on http://localhost:8000")
    print("="*50 + "\n")
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
