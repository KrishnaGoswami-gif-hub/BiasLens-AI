import React from 'react';
import { AnalysisResult } from '../types';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';
import { AlertTriangle, ThumbsUp, ThumbsDown, Minus, Info, CheckCircle2 } from 'lucide-react';

interface Props {
  data: AnalysisResult;
}

const SentimentBiasView: React.FC<Props> = ({ data }) => {
  const sentimentData = [
    { name: 'Positive', value: data.sentiment.distribution.positive, color: '#10b981' }, // Emerald-500
    { name: 'Neutral', value: data.sentiment.distribution.neutral, color: '#94a3b8' },  // Slate-400
    { name: 'Negative', value: data.sentiment.distribution.negative, color: '#ef4444' }, // Red-500
  ];

  const getSentimentIcon = () => {
    if (data.sentiment.label === 'Positive') return <ThumbsUp className="w-5 h-5 text-emerald-500" />;
    if (data.sentiment.label === 'Negative') return <ThumbsDown className="w-5 h-5 text-red-500" />;
    return <Minus className="w-5 h-5 text-slate-500" />;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Sentiment Analysis */}
      <div className="bg-white rounded-xl shadow-lg shadow-slate-100 border border-slate-100 p-6 flex flex-col h-full">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-bold text-slate-800">Sentiment Analysis</h3>
            <p className="text-xs text-slate-400 mt-1">VADER Compound Score Distribution</p>
          </div>
          <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 rounded-full border border-slate-200">
            {getSentimentIcon()}
            <span className="text-sm font-bold text-slate-700">{data.sentiment.label}</span>
            <span className="text-xs font-mono text-slate-400">| Score: {data.sentiment.score.toFixed(2)}</span>
          </div>
        </div>
        
        <div className="flex-grow flex items-center justify-center">
          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart layout="vertical" data={sentimentData} barSize={24}>
                <XAxis type="number" hide />
                <YAxis dataKey="name" type="category" width={70} tick={{fontSize: 12, fill: '#64748b', fontWeight: 500}} axisLine={false} tickLine={false} />
                <Tooltip cursor={{fill: '#f1f5f9'}} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                <Bar dataKey="value" radius={[0, 4, 4, 0]} background={{ fill: '#f8fafc' }}>
                  {sentimentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        
        <div className="mt-4 p-3 bg-slate-50 rounded-lg text-xs text-slate-500 leading-relaxed border border-slate-100 flex gap-2">
            <Info className="w-4 h-4 text-slate-400 flex-shrink-0 mt-0.5" />
            <p>
                Calculated using the NLTK VADER lexicon, which is specifically tuned for social media text. 
                Scores range from -1 (Extremely Negative) to +1 (Extremely Positive).
            </p>
        </div>
      </div>

      {/* Bias Detection */}
      <div className="bg-white rounded-xl shadow-lg shadow-slate-100 border border-slate-100 p-6 h-full">
        <div className="mb-6">
            <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-500" />
                Detected Biases
            </h3>
            <p className="text-xs text-slate-400 mt-1">Rule-based bias classification results</p>
        </div>
        
        <div className="space-y-4">
          {data.bias.map((bias, idx) => (
            <div key={idx} className={`p-4 rounded-xl border ${
                bias.type === 'Confirmation Bias' ? 'bg-gradient-to-br from-blue-50 to-white border-blue-200' :
                bias.type === 'Negativity Bias' ? 'bg-gradient-to-br from-red-50 to-white border-red-200' :
                'bg-slate-50 border-slate-200'
            } transition-all hover:shadow-md`}>
              <div className="flex justify-between items-center mb-2">
                <span className={`font-bold ${
                    bias.type === 'Confirmation Bias' ? 'text-blue-700' :
                    bias.type === 'Negativity Bias' ? 'text-red-700' : 'text-slate-700'
                }`}>{bias.type}</span>
                <span className="text-xs font-mono bg-white px-2 py-1 rounded border border-slate-200 shadow-sm text-slate-600 font-semibold">
                    Conf: {(bias.confidence * 100).toFixed(0)}%
                </span>
              </div>
              <p className="text-sm text-slate-600 mb-3 leading-relaxed">{bias.description}</p>
              
              {bias.triggers.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                      {bias.triggers.map((t, i) => (
                          <span key={i} className="px-2 py-1 text-xs rounded-md bg-white border border-slate-200 text-slate-700 font-medium shadow-sm">
                              "{t}"
                          </span>
                      ))}
                  </div>
              )}
            </div>
          ))}
          {data.bias.length === 0 && (
             <div className="flex flex-col items-center justify-center py-10 text-slate-400 border-2 border-dashed border-slate-100 rounded-xl">
                 <div className="w-10 h-10 bg-slate-50 rounded-full flex items-center justify-center mb-2">
                    <CheckCircle2 className="w-5 h-5 text-green-500" />
                 </div>
                 <span className="text-sm">No significant bias patterns detected.</span>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SentimentBiasView;