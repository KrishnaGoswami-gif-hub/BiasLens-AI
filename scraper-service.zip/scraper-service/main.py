import time
from db.database import DatabaseManager
from scrapers.reddit_scraper import RedditScraper
from scrapers.news_scraper import NewsScraper

def main():
    print("="*50)
    print("🧠 CBIE Dynamic Knowledge Acquisition Pipeline")
    print("="*50)
    
    # Initialize DB (MongoDB or JSON fallback)
    db = DatabaseManager()
    
    # Initialize Scrapers
    reddit_scraper = RedditScraper()
    news_scraper = NewsScraper()
    
    # 1. Scrape News (No API key needed)
    print("\n--- Phase 1: Scraping News Articles ---")
    news_data = news_scraper.scrape_feeds(limit_per_feed=10)
    db.save_documents(news_data, source_name="news_rss")
    
    # 2. Scrape Reddit (Requires API Key in .env to work)
    print("\n--- Phase 2: Scraping Social Media (Reddit) ---")
    # You can scrape multiple debate/opinion subreddits
    topics = ["changemyview", "unpopularopinion", "politics"]
    
    for topic in topics:
        reddit_data = reddit_scraper.scrape_subreddit(subreddit_name=topic, limit=5)
        if reddit_data:
            db.save_documents(reddit_data, source_name=f"reddit_{topic}")
            time.sleep(1) # Be nice to the API
        else:
            if not reddit_scraper.is_configured:
                break # Don't try other subreddits if API is missing
                
    print("\n" + "="*50)
    print("✅ Scraping Pipeline Complete!")
    print("Hint: To test Reddit scraping, edit 'scraper-service/.env' with a PRAW client ID & Secret.")

if __name__ == "__main__":
    main()
