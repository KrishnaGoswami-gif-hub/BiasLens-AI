import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';
import { motion } from 'framer-motion';

interface BiasDistributionProps {
  biases: Array<{
    type: string;
    count: number;
    color: string;
  }>;
}

const BiasDistributionChart: React.FC<BiasDistributionProps> = ({ biases }) => {
  const COLORS = ['#6366f1', '#a855f7', '#ec4899', '#f59e0b', '#10b981'];

  // Filter out biases with zero count
  const data = biases
    .filter(bias => bias.count > 0)
    .map((bias, index) => ({
      name: bias.type,
      value: bias.count,
      color: bias.color || COLORS[index % COLORS.length]
    }));

  // If no data, show placeholder
  if (data.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100"
      >
        <h3 className="text-xl font-bold text-slate-900 mb-4">Bias Distribution</h3>
        <div className="h-[300px] flex items-center justify-center text-slate-400">
          No bias data available
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100"
    >
      <h3 className="text-xl font-bold text-slate-900 mb-4">Bias Distribution</h3>
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            labelLine={false}
            label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
            outerRadius={100}
            fill="#8884d8"
            dataKey="value"
            animationBegin={0}
            animationDuration={800}
          >
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Pie>
          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </motion.div>
  );
};

export default BiasDistributionChart;
