import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Download, FileText, Image, CheckCircle, Loader } from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { AnalysisResult } from '../types';

interface ExportPageProps {
  analysisResult: AnalysisResult | null;
  inputText: string;
}

const ExportPage: React.FC<ExportPageProps> = ({ analysisResult, inputText }) => {
  const [exporting, setExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState(false);

  const generatePDFReport = async () => {
    if (!analysisResult) return;

    setExporting(true);
    setExportSuccess(false);

    try {
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      let yPosition = 20;

      // Helper function to add new page if needed
      const checkPageBreak = (requiredSpace: number) => {
        if (yPosition + requiredSpace > pageHeight - 20) {
          pdf.addPage();
          yPosition = 20;
          return true;
        }
        return false;
      };

      // Title Page
      pdf.setFontSize(28);
      pdf.setTextColor(67, 56, 202);
      pdf.text('Cognitive Bias Analysis', pageWidth / 2, yPosition, { align: 'center' });
      yPosition += 10;
      pdf.setFontSize(18);
      pdf.text('Comprehensive Report', pageWidth / 2, yPosition, { align: 'center' });
      
      yPosition += 15;
      pdf.setFontSize(10);
      pdf.setTextColor(100, 100, 100);
      pdf.text(`Generated: ${new Date().toLocaleString()}`, pageWidth / 2, yPosition, { align: 'center' });

      // Executive Summary
      yPosition += 20;
      pdf.setFontSize(16);
      pdf.setTextColor(0, 0, 0);
      pdf.text('Executive Summary', 20, yPosition);
      
      yPosition += 8;
      pdf.setFontSize(10);
      pdf.setTextColor(60, 60, 60);
      const summaryLines = pdf.splitTextToSize(analysisResult.executiveSummary, pageWidth - 40);
      pdf.text(summaryLines, 20, yPosition);
      yPosition += summaryLines.length * 5 + 10;

      // Main Topic
      checkPageBreak(20);
      pdf.setFontSize(14);
      pdf.setTextColor(0, 0, 0);
      pdf.text('Main Topic', 20, yPosition);
      yPosition += 8;
      pdf.setFontSize(11);
      pdf.setTextColor(79, 70, 229);
      pdf.text(analysisResult.mainTopic, 20, yPosition);
      yPosition += 15;

      // Sentiment Analysis Chart
      checkPageBreak(80);
      pdf.setFontSize(16);
      pdf.setTextColor(0, 0, 0);
      pdf.text('Sentiment Analysis', 20, yPosition);
      yPosition += 10;

      const sentimentChart = document.getElementById('sentiment-chart');
      if (sentimentChart) {
        const canvas = await html2canvas(sentimentChart, { scale: 2, backgroundColor: '#ffffff' });
        const imgData = canvas.toDataURL('image/png');
        const imgWidth = pageWidth - 40;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        if (yPosition + imgHeight > pageHeight - 20) {
          pdf.addPage();
          yPosition = 20;
        }
        pdf.addImage(imgData, 'PNG', 20, yPosition, imgWidth, imgHeight);
        yPosition += imgHeight + 15;
      }

      // Bias Distribution Chart
      checkPageBreak(80);
      pdf.setFontSize(16);
      pdf.setTextColor(0, 0, 0);
      pdf.text('Bias Distribution', 20, yPosition);
      yPosition += 10;

      const biasChart = document.getElementById('bias-chart');
      if (biasChart) {
        const canvas = await html2canvas(biasChart, { scale: 2, backgroundColor: '#ffffff' });
        const imgData = canvas.toDataURL('image/png');
        const imgWidth = pageWidth - 40;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        if (yPosition + imgHeight > pageHeight - 20) {
          pdf.addPage();
          yPosition = 20;
        }
        pdf.addImage(imgData, 'PNG', 20, yPosition, imgWidth, imgHeight);
        yPosition += imgHeight + 15;
      }

      // Confidence Scores Chart
      checkPageBreak(80);
      pdf.setFontSize(16);
      pdf.setTextColor(0, 0, 0);
      pdf.text('Confidence Scores', 20, yPosition);
      yPosition += 10;

      const confidenceChart = document.getElementById('confidence-chart');
      if (confidenceChart) {
        const canvas = await html2canvas(confidenceChart, { scale: 2, backgroundColor: '#ffffff' });
        const imgData = canvas.toDataURL('image/png');
        const imgWidth = pageWidth - 40;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        if (yPosition + imgHeight > pageHeight - 20) {
          pdf.addPage();
          yPosition = 20;
        }
        pdf.addImage(imgData, 'PNG', 20, yPosition, imgWidth, imgHeight);
        yPosition += imgHeight + 15;
      }

      // Topic Heatmap
      checkPageBreak(80);
      pdf.setFontSize(16);
      pdf.setTextColor(0, 0, 0);
      pdf.text('Topic Analysis Heatmap', 20, yPosition);
      yPosition += 10;

      const topicHeatmap = document.getElementById('topic-heatmap');
      if (topicHeatmap) {
        const canvas = await html2canvas(topicHeatmap, { scale: 2, backgroundColor: '#ffffff' });
        const imgData = canvas.toDataURL('image/png');
        const imgWidth = pageWidth - 40;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        
        if (yPosition + imgHeight > pageHeight - 20) {
          pdf.addPage();
          yPosition = 20;
        }
        pdf.addImage(imgData, 'PNG', 20, yPosition, imgWidth, imgHeight);
        yPosition += imgHeight + 15;
      }

      // Detailed Bias Indicators
      pdf.addPage();
      yPosition = 20;
      pdf.setFontSize(16);
      pdf.setTextColor(0, 0, 0);
      pdf.text('Detected Biases - Detailed Analysis', 20, yPosition);
      yPosition += 10;
      
      analysisResult.bias.forEach((bias, index) => {
        checkPageBreak(35);
        pdf.setFontSize(12);
        pdf.setTextColor(168, 85, 247);
        pdf.text(`${index + 1}. ${bias.type}`, 20, yPosition);
        yPosition += 6;
        pdf.setFontSize(10);
        pdf.setTextColor(60, 60, 60);
        const evidenceLines = pdf.splitTextToSize(`Evidence: ${bias.evidence}`, pageWidth - 40);
        pdf.text(evidenceLines, 25, yPosition);
        yPosition += evidenceLines.length * 5 + 3;
        pdf.text(`Confidence: ${(bias.confidence * 100).toFixed(1)}%`, 25, yPosition);
        yPosition += 10;
      });

      // Association Rules
      if (analysisResult.rules.length > 0) {
        checkPageBreak(30);
        pdf.setFontSize(16);
        pdf.setTextColor(0, 0, 0);
        pdf.text('Association Rules', 20, yPosition);
        yPosition += 10;

        analysisResult.rules.slice(0, 10).forEach((rule, index) => {
          checkPageBreak(20);
          pdf.setFontSize(10);
          pdf.setTextColor(60, 60, 60);
          pdf.text(`${index + 1}. ${rule.antecedent} → ${rule.consequent}`, 20, yPosition);
          yPosition += 6;
          pdf.text(`   Support: ${(rule.support * 100).toFixed(1)}% | Confidence: ${(rule.confidence * 100).toFixed(1)}%`, 20, yPosition);
          yPosition += 8;
        });
      }

      // Footer on all pages
      const totalPages = (pdf as any).internal.getNumberOfPages();
      for (let i = 1; i <= totalPages; i++) {
        pdf.setPage(i);
        pdf.setFontSize(8);
        pdf.setTextColor(150, 150, 150);
        pdf.text(
          'Generated by Cognitive Bias Miner - AI-Powered Bias Detection',
          pageWidth / 2,
          pageHeight - 10,
          { align: 'center' }
        );
        pdf.text(`Page ${i} of ${totalPages}`, pageWidth - 20, pageHeight - 10, { align: 'right' });
      }

      // Save PDF
      pdf.save(`cognitive-bias-complete-report-${Date.now()}.pdf`);
      
      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (error) {
      console.error('PDF generation failed:', error);
      alert('Failed to generate PDF report. Please try again.');
    } finally {
      setExporting(false);
    }
  };

  const exportAsImage = async (elementId: string, filename: string) => {
    setExporting(true);
    try {
      const element = document.getElementById(elementId);
      if (!element) {
        alert('Element not found');
        return;
      }

      const canvas = await html2canvas(element, {
        scale: 2,
        backgroundColor: '#ffffff',
      });

      const link = document.createElement('a');
      link.download = `${filename}-${Date.now()}.png`;
      link.href = canvas.toDataURL();
      link.click();

      setExportSuccess(true);
      setTimeout(() => setExportSuccess(false), 3000);
    } catch (error) {
      console.error('Image export failed:', error);
      alert('Failed to export image. Please try again.');
    } finally {
      setExporting(false);
    }
  };

  return (
    <section className="py-20 bg-gradient-to-br from-slate-50 to-primary-50/20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Export Reports
          </h2>
          <p className="text-xl text-slate-600">
            Download comprehensive PDF reports and visualizations for your records
          </p>
        </motion.div>

        {!analysisResult ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5 }}
            className="bg-white rounded-2xl p-12 shadow-lg border border-slate-100 text-center"
          >
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-slate-100 flex items-center justify-center">
              <FileText className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-2xl font-bold text-slate-900 mb-3">No Analysis Available</h3>
            <p className="text-slate-600 mb-6">
              Please run an analysis first to generate exportable reports
            </p>
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="inline-flex items-center px-6 py-3 rounded-xl bg-gradient-to-r from-primary-600 to-secondary-600 text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300"
            >
              Go to Analysis
            </button>
          </motion.div>
        ) : (
          <div className="space-y-6">
            {/* PDF Report */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
              className="bg-white rounded-2xl p-8 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300"
            >
              <div className="flex items-start gap-6">
                <div className="p-4 rounded-xl bg-gradient-to-br from-primary-500 to-primary-600 text-white shadow-lg">
                  <FileText className="w-8 h-8" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Complete Analysis Report</h3>
                  <p className="text-slate-600 mb-4">
                    Comprehensive PDF report including executive summary, all visualizations (sentiment chart, bias distribution, confidence scores, topic heatmap), detected biases, and association rules
                  </p>
                  <ul className="space-y-2 text-sm text-slate-600 mb-6">
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      All charts and visualizations included
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      Detailed bias analysis with evidence
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      Association rules and patterns
                    </li>
                    <li className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      Professional formatting with page numbers
                    </li>
                  </ul>
                  <button
                    onClick={generatePDFReport}
                    disabled={exporting}
                    className="inline-flex items-center gap-2 px-8 py-4 rounded-xl bg-gradient-to-r from-primary-600 to-secondary-600 text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed text-lg"
                  >
                    {exporting ? (
                      <>
                        <Loader className="w-6 h-6 animate-spin" />
                        Generating Complete PDF...
                      </>
                    ) : exportSuccess ? (
                      <>
                        <CheckCircle className="w-6 h-6" />
                        Downloaded Successfully!
                      </>
                    ) : (
                      <>
                        <Download className="w-6 h-6" />
                        Download Complete PDF Report
                      </>
                    )}
                  </button>
                </div>
              </div>
            </motion.div>

            {/* Export Info */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="bg-primary-50 rounded-xl p-6 border border-primary-100"
            >
              <h4 className="font-semibold text-slate-900 mb-2">Export Information</h4>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="text-primary-600">•</span>
                  PDF includes all analysis data, metrics, and visualizations in one file
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary-600">•</span>
                  Charts are exported as high-resolution images within the PDF
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary-600">•</span>
                  All exports are generated locally - no data is sent to servers
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-primary-600">•</span>
                  Perfect for presentations, reports, and archiving
                </li>
              </ul>
            </motion.div>
          </div>
        )}
      </div>
    </section>
  );
};

export default ExportPage;
