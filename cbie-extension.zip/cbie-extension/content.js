console.log("CBIE: Cognitive Bias Extension Loaded.");

const API_URL = "http://localhost:8000/api/analyze";

// Explainable AI (XAI) Word Highlighter Logic
function applyXAIHighlights(node, analysisData) {
    if (analysisData.risk_level === "low") return;

    let html = node.innerHTML;
    
    // For every detected bias, we'll extract "trigger words" using a mock Transformer Attention algorithm
    // (In reality, we extract words flagged by Vader or regex logic from the backend)
    analysisData.detected_biases.forEach(bias => {
        // Extract words longer than 4 chars from the "evidence" string to simulate attention highlights
        const words = bias.evidence.split(/\s+/).filter(w => w.length > 4); 
        
        // Take a few words as the "Attention Triggers" for XAI
        const triggers = words.slice(0, 2); 
        
        triggers.forEach(trigger => {
            // Very simple escape for regex
            const safeTrigger = trigger.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const regex = new RegExp(`\\b(${safeTrigger})\\b`, "gi");
            
            const tooltipHTML = `
                <span class="cbie-trigger-word">$1
                    <span class="cbie-tooltip">
                        <span class="cbie-tooltip-title">💡 XAI Analysis: ${bias.type}</span>
                        Model Confidence: ${(bias.confidence * 100).toFixed(1)}%<br>
                        "This specific phrasing strongly correlates with irrational or emotional argumentation."
                        <div class="cbie-suggestion">
                            ${analysisData.suggestions.length > 0 ? 'AI Suggestion: ' + analysisData.suggestions[0] : 'Try rephrasing to maintain academic neutrality.'}
                        </div>
                    </span>
                </span>`;
            
            html = html.replace(regex, tooltipHTML);
        });
    });

    // Only update if changes happened to avoid breaking React Virtual DOMs excessively
    if (html !== node.innerHTML) {
        node.innerHTML = html;
        node.classList.add("cbie-analyzed", `risk-${analysisData.risk_level}`);
    }
}

// Function to fetch analysis from our FastAPI microservice
async function analyzeNode(node) {
    if (node.dataset.cbieScanned) return;
    node.dataset.cbieScanned = "true";

    const text = node.innerText;
    if (text.length < 15) return; // Ignore very short UI text

    try {
        const response = await fetch(API_URL, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ text: text })
        });
        
        if (response.ok) {
            const data = await response.json();
            // Apply XAI Engine
            applyXAIHighlights(node, data);
        }
    } catch (error) {
        console.error("CBIE Backend Offline:", error);
    }
}

// Observer to scan new Tweets or Reddit comments as user scrolls
const observer = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
            if (node.nodeType === 1) { // Element Node
                // Twitter Tweet Text
                const tweets = node.querySelectorAll('[data-testid="tweetText"]');
                // Reddit Comment Text
                const redditComments = node.querySelectorAll('[data-testid="comment"], .md');
                
                tweets.forEach(analyzeNode);
                redditComments.forEach(analyzeNode);
            }
        });
    });
});

// --- UNIVERSAL RIGHT-CLICK MODAL LOGIC ---
function showCbieModal(biasData, originalText) {
    let existingModal = document.getElementById("cbie-universal-modal");
    if (existingModal) existingModal.remove();

    const modal = document.createElement("div");
    modal.id = "cbie-universal-modal";

    let contentHTML = `
        <div style="font-size: 11px; color:#fca5a5; text-transform:uppercase; margin-bottom: 8px; font-weight:bold;">
            Risk Level: ${biasData.risk_level.toUpperCase()}
        </div>
        <div style="margin-bottom: 12px; font-size: 13px;">
            <strong>Sentiment:</strong> Neg (${(biasData.sentiment.negativeScore*100).toFixed(0)}%) | Neu (${(biasData.sentiment.neutralScore*100).toFixed(0)}%) | Pos (${(biasData.sentiment.positiveScore*100).toFixed(0)}%)
        </div>
    `;

    if (biasData.detected_biases.length === 0) {
        contentHTML += `<div style="color: #6ee7b7; font-weight:bold;">No irrational cognitive biases detected.</div>`;
    } else {
        contentHTML += `<div style="color: #f87171; font-weight:bold; margin-bottom:4px;">Detected Biases:</div>`;
        biasData.detected_biases.forEach(b => {
            contentHTML += `<div style="margin-bottom:6px; background:#451a1a; padding:6px; border-radius:4px; border-left:3px solid #ef4444;">
                <strong>${b.type}</strong> (${(b.confidence*100).toFixed(0)}%)<br>
                <em style="color:#fca5a5">"${b.evidence}"</em>
            </div>`;
        });
    }

    if (biasData.suggestions.length > 0) {
        contentHTML += `<div style="margin-top:12px; border-top:1px solid #374151; padding-top:8px;">
            <strong style="color: #60a5fa;">AI Suggestion:</strong><br>
            <span style="color: #93c5fd; font-style:italic;">${biasData.suggestions[0]}</span>
        </div>`;
    }

    modal.innerHTML = `
        <div id="cbie-modal-header">
            <span>🧠 CBIE Report</span>
            <span id="cbie-modal-close">✕</span>
        </div>
        <div id="cbie-modal-body">
            ${contentHTML}
        </div>
    `;

    document.body.appendChild(modal);

    document.getElementById("cbie-modal-close").addEventListener("click", () => {
        modal.remove();
    });
}

chrome.runtime.onMessage.addListener(async (request, sender, sendResponse) => {
    if (request.action === "analyze_selection") {
        try {
            // Show loading modal briefly
            const loadingModal = document.createElement("div");
            loadingModal.id = "cbie-universal-modal";
            loadingModal.innerHTML = `<div id="cbie-modal-header"><span>🧠 CBIE Processing...</span></div><div id="cbie-modal-body">Analyzing text using local ML models...</div>`;
            document.body.appendChild(loadingModal);

            const response = await fetch(API_URL, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ text: request.text })
            });

            loadingModal.remove();

            if (response.ok) {
                const data = await response.json();
                showCbieModal(data, request.text);
            }
        } catch (error) {
            console.error("CBIE Backend Error:", error);
            alert("CBIE Offline: Make sure your FastAPI server is running on localhost:8000!");
        }
    }
});


// --- CONTINUOUS DOM SCANNER (Restricted to social media to preserve performance) ---
const hostname = window.location.hostname;
if (hostname.includes("twitter.com") || hostname.includes("x.com") || hostname.includes("reddit.com")) {
    console.log("CBIE: Activating continuous DOM observer for Social Media.");
    observer.observe(document.body, { childList: true, subtree: true });

    // Initial scan
    setTimeout(() => {
        document.querySelectorAll('[data-testid="tweetText"], [data-testid="comment"], .md').forEach(analyzeNode);
    }, 2000);
}
