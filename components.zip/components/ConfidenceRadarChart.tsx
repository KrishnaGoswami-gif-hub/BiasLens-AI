import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer, Tooltip } from 'recharts';
import { motion } from 'framer-motion';

interface ConfidenceRadarProps {
  metrics: Array<{
    category: string;
    score: number;
  }>;
}

const ConfidenceRadarChart: React.FC<ConfidenceRadarProps> = ({ metrics }) => {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100"
    >
      <h3 className="text-xl font-bold text-slate-900 mb-4">Confidence Scores</h3>
      <ResponsiveContainer width="100%" height={300}>
        <RadarChart data={metrics}>
          <PolarGrid stroke="#e2e8f0" />
          <PolarAngleAxis dataKey="category" tick={{ fill: '#64748b', fontSize: 12 }} />
          <PolarRadiusAxis angle={90} domain={[0, 100]} tick={{ fill: '#64748b' }} />
          <Radar
            name="Confidence"
            dataKey="score"
            stroke="#6366f1"
            fill="#6366f1"
            fillOpacity={0.6}
            animationBegin={200}
            animationDuration={800}
          />
          <Tooltip />
        </RadarChart>
      </ResponsiveContainer>
    </motion.div>
  );
};

export default ConfidenceRadarChart;
