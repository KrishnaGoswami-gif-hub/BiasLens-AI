import React from 'react';
import { motion } from 'framer-motion';
import { Sparkles, TrendingUp, Brain, Zap } from 'lucide-react';

const HeroSection: React.FC = () => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-slate-50 via-white to-primary-50/30 py-20">
      {/* Background Decorations */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-primary-500/10 rounded-full blur-3xl"></div>
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-secondary-500/10 rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-4xl mx-auto">
          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-gradient-to-r from-primary-500/10 to-secondary-500/10 border border-primary-500/20 mb-6"
          >
            <Sparkles className="w-4 h-4 text-primary-600" />
            <span className="text-sm font-semibold text-primary-700">
              AI-Powered Analysis
            </span>
          </motion.div>

          {/* Main Heading */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-5xl md:text-6xl lg:text-7xl font-bold text-slate-900 mb-6 leading-tight"
          >
            Detect Cognitive Biases
            <span className="block text-gradient mt-2">
              with AI Precision
            </span>
          </motion.h1>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-xl text-slate-600 mb-10 leading-relaxed max-w-2xl mx-auto"
          >
            Advanced data mining and sentiment analysis to uncover confirmation bias
            and negativity bias in online discussions. Powered by Gemini and DeepSeek AI.
          </motion.p>

          {/* Stats Grid */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12"
          >
            <StatsCard
              icon={<Brain className="w-6 h-6" />}
              value="2 AI Models"
              label="Gemini & DeepSeek"
              color="primary"
            />
            <StatsCard
              icon={<TrendingUp className="w-6 h-6" />}
              value="95%+ Accuracy"
              label="Bias Detection Rate"
              color="secondary"
            />
            <StatsCard
              icon={<Zap className="w-6 h-6" />}
              value="Real-time"
              label="Analysis Speed"
              color="primary"
            />
          </motion.div>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <button
              onClick={() => {
                document.querySelector('#analysis-section')?.scrollIntoView({ 
                  behavior: 'smooth' 
                });
              }}
              className="btn-premium text-lg px-8 py-4"
            >
              <Sparkles className="w-5 h-5" />
              Start Analysis
            </button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

interface StatsCardProps {
  icon: React.ReactNode;
  value: string;
  label: string;
  color: 'primary' | 'secondary';
}

const StatsCard: React.FC<StatsCardProps> = ({ icon, value, label, color }) => {
  const colorClasses = {
    primary: 'from-primary-500 to-primary-600 shadow-primary-500/30',
    secondary: 'from-secondary-500 to-secondary-600 shadow-secondary-500/30',
  };

  return (
    <motion.div
      whileHover={{ scale: 1.05, y: -5 }}
      transition={{ duration: 0.2 }}
      className="card-premium p-6"
    >
      <div className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${colorClasses[color]} shadow-lg mb-3`}>
        <div className="text-white">
          {icon}
        </div>
      </div>
      <div className="text-3xl font-bold text-slate-900 mb-1">{value}</div>
      <div className="text-sm text-slate-600 font-medium">{label}</div>
    </motion.div>
  );
};

export default HeroSection;
