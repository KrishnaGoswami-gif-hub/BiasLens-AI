import React from "react";
import { AnalysisResult } from "../types";
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ZAxis,
} from "recharts";
import { Network, HelpCircle } from "lucide-react";

interface Props {
  data: AnalysisResult;
}

const AssociationRulesView: React.FC<Props> = ({ data }) => {
  const chartData = data.rules.map((rule, idx) => ({
    x: rule.support,
    y: rule.confidence,
    z: rule.lift,
    name: `${rule.antecedent.join(", ")} -> ${rule.consequent.join(", ")}`,
    ...rule,
  }));

  return (
    <div className="bg-white rounded-xl shadow-lg shadow-slate-100 border border-slate-100 p-6">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <Network className="w-5 h-5 text-indigo-500" />
            Association Rule Mining
          </h3>
          <p className="text-sm text-slate-500 mt-1">
            Discovering hidden relationships using the Apriori Algorithm.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Table View */}
        <div className="lg:col-span-2 overflow-hidden rounded-xl border border-slate-200 bg-slate-50/50">
          <table className="min-w-full divide-y divide-slate-200">
            <thead className="bg-slate-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider">
                  Rule (Antecedent → Consequent)
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider group cursor-help relative">
                  Support
                  <div className="hidden group-hover:block absolute z-10 bottom-full left-0 w-48 p-2 bg-slate-800 text-white text-xs rounded shadow-lg mb-1 font-normal normal-case">
                    How frequently this pattern appears in the entire dataset.
                  </div>
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider group cursor-help relative">
                  Confidence
                  <div className="hidden group-hover:block absolute z-10 bottom-full left-0 w-48 p-2 bg-slate-800 text-white text-xs rounded shadow-lg mb-1 font-normal normal-case">
                    Likelihood of Consequent appearing given Antecedent.
                  </div>
                </th>
                <th className="px-6 py-3 text-left text-xs font-semibold text-slate-500 uppercase tracking-wider group cursor-help relative">
                  Lift
                  <div className="hidden group-hover:block absolute z-10 bottom-full left-0 w-48 p-2 bg-slate-800 text-white text-xs rounded shadow-lg mb-1 font-normal normal-case">
                    Strength of association. &gt; 1 means positive correlation.
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-slate-200">
              {data.rules.map((rule, idx) => (
                <tr
                  key={idx}
                  className="hover:bg-indigo-50/30 transition-colors"
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-700">
                    <span className="font-semibold text-indigo-700 bg-indigo-50 px-2 py-1 rounded border border-indigo-100">{`{${rule.antecedent.join(", ")}}`}</span>
                    <span className="mx-2 text-slate-400">→</span>
                    <span className="font-semibold text-slate-900 bg-slate-100 px-2 py-1 rounded border border-slate-200">{`{${rule.consequent.join(", ")}}`}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600 font-mono">
                    {rule.support.toFixed(2)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-slate-600">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-slate-100 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-emerald-500 h-1.5 rounded-full"
                          style={{ width: `${rule.confidence * 100}%` }}
                        ></div>
                      </div>
                      <span className="font-mono">
                        {rule.confidence.toFixed(2)}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-mono font-bold text-slate-700">
                    {rule.lift.toFixed(2)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Chart View with Legend */}
        <div className="flex flex-col gap-4">
          <div className="h-64 w-full bg-white rounded-xl p-4 border border-slate-200 shadow-sm">
            <h4 className="text-xs font-bold text-slate-400 uppercase mb-4 text-center tracking-wider">
              Metric Correlation
            </h4>
            <ResponsiveContainer width="100%" height="100%">
              <ScatterChart
                margin={{ top: 10, right: 10, bottom: 10, left: 10 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                <XAxis
                  type="number"
                  dataKey="x"
                  name="Support"
                  unit=""
                  label={{
                    value: "Support",
                    position: "bottom",
                    offset: 0,
                    fontSize: 10,
                  }}
                  tick={{ fontSize: 10 }}
                />
                <YAxis
                  type="number"
                  dataKey="y"
                  name="Confidence"
                  unit=""
                  label={{
                    value: "Confidence",
                    angle: -90,
                    position: "left",
                    offset: 0,
                    fontSize: 10,
                  }}
                  tick={{ fontSize: 10 }}
                />
                <ZAxis
                  type="number"
                  dataKey="z"
                  range={[50, 400]}
                  name="Lift"
                />
                <Tooltip
                  cursor={{ strokeDasharray: "3 3" }}
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-800 text-white p-3 shadow-xl rounded-lg text-xs border border-slate-700">
                          <p className="font-bold mb-2 text-indigo-300 border-b border-slate-600 pb-1">
                            {data.name}
                          </p>
                          <div className="grid grid-cols-2 gap-x-4 gap-y-1">
                            <span className="text-slate-400">Support:</span>{" "}
                            <span>{data.x.toFixed(2)}</span>
                            <span className="text-slate-400">
                              Confidence:
                            </span>{" "}
                            <span>{data.y.toFixed(2)}</span>
                            <span className="text-slate-400">Lift:</span>{" "}
                            <span className="text-emerald-400 font-bold">
                              {data.z.toFixed(2)}
                            </span>
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Scatter
                  name="Rules"
                  data={chartData}
                  fill="#6366f1"
                  fillOpacity={0.6}
                  stroke="#4f46e5"
                />
              </ScatterChart>
            </ResponsiveContainer>
          </div>

          <div className="p-4 bg-indigo-50 rounded-xl border border-indigo-100 text-xs text-indigo-900">
            <div className="flex items-start gap-2">
              <HelpCircle className="w-4 h-4 text-indigo-500 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-bold mb-1">Interpretation Guide:</p>
                <p className="opacity-80">
                  High <strong>Lift (&gt;1)</strong> indicates a strong
                  connection between the trigger words and the bias type,
                  suggesting a meaningful pattern rather than coincidence.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssociationRulesView;
