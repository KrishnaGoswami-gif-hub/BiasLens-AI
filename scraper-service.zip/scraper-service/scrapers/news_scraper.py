import feedparser
from bs4 import BeautifulSoup

class NewsScraper:
    def __init__(self):
        # Targeting opinion and politics sections which are rich in cognitive biases
        self.rss_feeds = {
            "BBC_World": "http://feeds.bbci.co.uk/news/world/rss.xml",
            "NYT_Opinion": "https://rss.nytimes.com/services/xml/rss/nyt/Opinion.xml",
            "CNN_Top": "http://rss.cnn.com/rss/cnn_topstories.rss"
        }

    def clean_html(self, raw_html):
        if not raw_html:
            return ""
        soup = BeautifulSoup(raw_html, "html.parser")
        return soup.get_text(separator=" ").strip()

    def scrape_feeds(self, limit_per_feed=5):
        results = []
        
        for name, url in self.rss_feeds.items():
            print(f"Scraping RSS feed: {name}...")
            try:
                feed = feedparser.parse(url)
                
                count = 0
                for entry in feed.entries:
                    if count >= limit_per_feed:
                        break
                        
                    # Clean any HTML from the summary component
                    summary_text = self.clean_html(getattr(entry, 'summary', ''))
                    
                    if summary_text:
                        document = {
                            "source": f"news_rss_{name}",
                            "title": getattr(entry, 'title', ''),
                            "text": summary_text,
                            "url": getattr(entry, 'link', ''),
                            "author": getattr(entry, 'author', 'unknown'),
                            "published": getattr(entry, 'published', '')
                        }
                        results.append(document)
                        count += 1
                        
            except Exception as e:
                print(f"Error scraping feed {name}: {e}")
                
        return results
