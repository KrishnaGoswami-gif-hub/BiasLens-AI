import React from 'react';
import { motion } from 'framer-motion';
import { FileText, Database, Brain, BarChart3, CheckCircle } from 'lucide-react';

const MethodologySection: React.FC = () => {
  const steps = [
    {
      icon: <FileText className="w-6 h-6" />,
      title: "Data Input",
      description: "Upload text or PDF documents containing online discussions or social media content"
    },
    {
      icon: <Database className="w-6 h-6" />,
      title: "Preprocessing",
      description: "Text tokenization, cleaning, and preparation using advanced NLP techniques"
    },
    {
      icon: <Brain className="w-6 h-6" />,
      title: "AI Analysis",
      description: "Dual AI models (Gemini & DeepSeek) analyze content for cognitive biases"
    },
    {
      icon: <BarChart3 className="w-6 h-6" />,
      title: "Pattern Mining",
      description: "Association rule mining and topic modeling to identify bias patterns"
    },
    {
      icon: <CheckCircle className="w-6 h-6" />,
      title: "Results",
      description: "Comprehensive report with visualizations, metrics, and actionable insights"
    }
  ];

  return (
    <section id="methodology" className="py-20 bg-gradient-to-br from-slate-50 to-primary-50/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            How It Works
          </h2>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Our advanced methodology combines AI, data mining, and NLP to detect cognitive biases
          </p>
        </motion.div>

        <div className="relative">
          {/* Connection Line */}
          <div className="absolute top-1/2 left-0 right-0 h-1 bg-gradient-to-r from-primary-500 to-secondary-500 transform -translate-y-1/2 hidden lg:block"></div>

          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8 relative">
            {steps.map((step, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="relative"
              >
                <div className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300">
                  <div className="flex flex-col items-center text-center">
                    <div className="w-16 h-16 rounded-full bg-gradient-to-br from-primary-500 to-secondary-500 flex items-center justify-center text-white shadow-lg mb-4 relative z-10">
                      {step.icon}
                    </div>
                    <div className="absolute -top-3 -right-3 w-8 h-8 rounded-full bg-primary-600 text-white flex items-center justify-center text-sm font-bold shadow-md">
                      {index + 1}
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 mb-2">{step.title}</h3>
                    <p className="text-sm text-slate-600 leading-relaxed">{step.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Technical Details */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.6 }}
          className="mt-16 bg-white rounded-2xl p-8 shadow-lg border border-slate-100"
        >
          <h3 className="text-2xl font-bold text-slate-900 mb-6">Technical Approach</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">NLP Techniques</h4>
              <ul className="space-y-2 text-slate-600">
                <li className="flex items-start">
                  <span className="text-primary-600 mr-2">•</span>
                  Tokenization and text normalization
                </li>
                <li className="flex items-start">
                  <span className="text-primary-600 mr-2">•</span>
                  Sentiment analysis with polarity scoring
                </li>
                <li className="flex items-start">
                  <span className="text-primary-600 mr-2">•</span>
                  Topic modeling using LDA
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">Data Mining</h4>
              <ul className="space-y-2 text-slate-600">
                <li className="flex items-start">
                  <span className="text-secondary-600 mr-2">•</span>
                  Association rule mining (Apriori algorithm)
                </li>
                <li className="flex items-start">
                  <span className="text-secondary-600 mr-2">•</span>
                  Pattern recognition and clustering
                </li>
                <li className="flex items-start">
                  <span className="text-secondary-600 mr-2">•</span>
                  Confidence and support metrics
                </li>
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default MethodologySection;
