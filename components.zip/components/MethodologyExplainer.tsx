import React from 'react';
import { Database, Filter, Binary, Network, Eye } from 'lucide-react';

const MethodologyExplainer: React.FC = () => {
  const steps = [
    {
      icon: <Filter className="w-5 h-5 text-blue-600" />,
      title: "1. Python NLP Pipeline",
      desc: "Simulating a Python environment using NLTK and Pandas. We perform Tokenization, Stopword Removal (using NLTK's English corpus), and Lemmatization (WordNet) to clean and standardize the raw text data."
    },
    {
      icon: <Binary className="w-5 h-5 text-green-600" />,
      title: "2. VADER Sentiment Analysis",
      desc: "We apply NLTK's VADER (Valence Aware Dictionary and sEntiment Reasoner). It calculates a Compound Score (-1 to 1) to classify comments as Positive, Neutral, or Negative, optimized for social media text."
    },
    {
      icon: <Eye className="w-5 h-5 text-amber-600" />,
      title: "3. Bias Logic (Human-In-The-Loop)",
      desc: "Biases are flagged using explicit rules: Confirmation Bias (Strong Sentiment + Absolutist words like 'always', 'all') and Negativity Bias (Negative Sentiment + Charged words like 'catastrophe')."
    },
    {
      icon: <Network className="w-5 h-5 text-purple-600" />,
      title: "4. Apriori Data Mining",
      desc: "Using the MLxtend library's Apriori algorithm, we discover frequent itemsets (Topics + Bias). We generate Association Rules with Support, Confidence, and Lift metrics to reveal hidden patterns."
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <div className="flex items-center gap-2 mb-6">
        <Database className="w-5 h-5 text-slate-500" />
        <h3 className="text-lg font-semibold text-slate-800">Technical Methodology (Stack: Python, Pandas, MLxtend)</h3>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {steps.map((step, idx) => (
          <div key={idx} className="p-4 bg-slate-50 rounded-lg border border-slate-100 flex flex-col h-full">
            <div className="flex items-center gap-2 mb-3">
              <div className="p-2 bg-white rounded-md shadow-sm border border-slate-200">
                {step.icon}
              </div>
              <span className="font-semibold text-slate-700 text-sm">{step.title}</span>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              {step.desc}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MethodologyExplainer;