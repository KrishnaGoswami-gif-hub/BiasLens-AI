import json
import os
from datetime import datetime
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure
from core.config import Config

class DatabaseManager:
    def __init__(self):
        self.use_mongodb = False
        self.collection = None
        
        try:
            # Try connecting to MongoDB
            self.client = MongoClient(Config.MONGO_URI, serverSelectionTimeoutMS=2000)
            # Actually test the connection
            self.client.admin.command('ping')
            self.db = self.client[Config.DB_NAME]
            self.collection = self.db[Config.COLLECTION_NAME]
            self.use_mongodb = True
            print("✓ Connected to MongoDB successfully.")
        except ConnectionFailure:
            print("⚠ MongoDB connection failed. Falling back to local JSON storage.")
            self.use_mongodb = False

    def save_documents(self, documents, source_name="unknown"):
        if not documents:
            print(f"No documents to save from {source_name}")
            return
            
        print(f"Saving {len(documents)} documents from {source_name}...")
        
        # Add metadata to documents
        for doc in documents:
            doc['scraped_at'] = datetime.now().isoformat()
            doc['source_type'] = source_name
            
        if self.use_mongodb:
            try:
                self.collection.insert_many(documents)
                print(f"✓ Saved {len(documents)} docs to MongoDB.")
                return
            except Exception as e:
                print(f"Error saving to MongoDB: {e}. Falling back to JSON.")
        
        # Fallback to JSON
        if Config.SAVE_TO_JSON_FALLBACK:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"{source_name}_{timestamp}.json"
            filepath = os.path.join(Config.DATA_DIR, filename)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(documents, f, indent=4, ensure_ascii=False)
            print(f"✓ Saved {len(documents)} docs to {filepath}")
