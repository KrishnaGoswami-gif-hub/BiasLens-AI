import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { motion } from 'framer-motion';

interface SentimentGaugeProps {
  sentiment: {
    positive: number;
    negative: number;
    neutral: number;
  };
}

const SentimentGauge: React.FC<SentimentGaugeProps> = ({ sentiment }) => {
  const data = [
    { name: 'Positive', value: sentiment.positive * 100, color: '#10b981' },
    { name: 'Neutral', value: sentiment.neutral * 100, color: '#64748b' },
    { name: 'Negative', value: sentiment.negative * 100, color: '#ef4444' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white rounded-2xl shadow-lg p-6 border border-slate-100"
    >
      <h3 className="text-xl font-bold text-slate-900 mb-4">Sentiment Analysis</h3>
      <ResponsiveContainer width="100%" height={250}>
        <BarChart data={data} layout="vertical">
          <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
          <XAxis type="number" domain={[0, 100]} tick={{ fill: '#64748b' }} />
          <YAxis dataKey="name" type="category" tick={{ fill: '#64748b' }} />
          <Tooltip />
          <Bar dataKey="value" radius={[0, 8, 8, 0]} animationDuration={800}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.color} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </motion.div>
  );
};

export default SentimentGauge;
