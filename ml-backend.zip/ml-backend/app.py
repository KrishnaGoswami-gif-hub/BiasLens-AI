from flask import Flask, request, jsonify
from flask_cors import CORS
import nltk
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from textblob import TextBlob
import random
import re
import os
import json
from collections import Counter
import joblib
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.stem import WordNetLemmatizer

app = Flask(__name__)
CORS(app)

# Initialize NLP tools
vader_analyzer = SentimentIntensityAnalyzer()
lemmatizer = WordNetLemmatizer()

try:
    stop_words = set(stopwords.words('english'))
except:
    stop_words = set()

# Bias detection patterns
BIAS_PATTERNS = {
    'confirmation': [
        r'\b(always|never|everyone|no one|all|none)\b',
        r'\b(obviously|clearly|undeniably|certainly)\b',
        r'\b(must|should|have to|need to)\b',
        r'\b(proof|evidence|shows|demonstrates)\s+(that|how)',
    ],
    'negativity': [
        r'\b(disaster|catastrophe|horrible|terrible|awful|dreadful)\b',
        r'\b(fail|failure|destroy|ruin|collapse|doom)\b',
        r'\b(worst|never work|impossible|hopeless)\b',
        r'\b(crisis|threat|danger|risk|problem)\b',
    ],
    'anchoring': [
        r'\b(first|initial|originally|started at)\b',
        r'\b(compared to|relative to|versus)\b',
    ],
    'availability': [
        r'\b(recently|lately|just heard|saw on)\b',
        r'\b(everyone knows|common knowledge|obvious)\b',
    ]
}

# Load ML model if available
ML_MODEL = None
ML_VECTORIZER = None
ML_METRICS = None

def load_ml_model():
    """Load trained ML model and vectorizer"""
    global ML_MODEL, ML_VECTORIZER, ML_METRICS
    
    model_path = 'models/bias_classifier.pkl'
    vectorizer_path = 'models/tfidf_vectorizer.pkl'
    metrics_path = 'models/training_metrics.json'
    
    if os.path.exists(model_path) and os.path.exists(vectorizer_path):
        try:
            ML_MODEL = joblib.load(model_path)
            ML_VECTORIZER = joblib.load(vectorizer_path)
            print("✓ ML model loaded successfully!")
            
            if os.path.exists(metrics_path):
                with open(metrics_path, 'r') as f:
                    ML_METRICS = json.load(f)
                print(f"  Model accuracy: {ML_METRICS['accuracy']:.2%}")
            
            return True
        except Exception as e:
            print(f"⚠ Warning: Could not load ML model: {e}")
            return False
    else:
        print("ℹ ML model not found. Run 'python train_model.py' to train the model.")
        print("  Using pattern-based detection only.")
        return False


def preprocess_text(text):
    """Advanced text preprocessing"""
    # Lowercase
    text = text.lower()
    
    # Remove special characters but keep sentence structure
    text = re.sub(r'[^a-zA-Z0-9\s\.]', '', text)
    
    # Tokenize
    tokens = word_tokenize(text)
    
    # Remove stopwords and lemmatize
    if stop_words:
        tokens = [lemmatizer.lemmatize(token) for token in tokens 
                  if token not in stop_words and len(token) > 2]
    else:
        tokens = [lemmatizer.lemmatize(token) for token in tokens if len(token) > 2]
    
    return tokens

def analyze_sentiment(text):
    """Enhanced sentiment analysis using VADER and TextBlob"""
    # VADER analysis
    vader_scores = vader_analyzer.polarity_scores(text)
    
    # TextBlob analysis
    blob = TextBlob(text)
    textblob_polarity = blob.sentiment.polarity
    
    # Ensemble: weighted average (VADER is better for social media/informal text)
    positive = (vader_scores['pos'] * 0.7 + max(0, textblob_polarity) * 0.3)
    negative = (vader_scores['neg'] * 0.7 + max(0, -textblob_polarity) * 0.3)
    neutral = vader_scores['neu']
    
    # Normalize
    total = positive + negative + neutral
    if total > 0:
        positive /= total
        negative /= total
        neutral /= total
    
    confidence = abs(vader_scores['compound'])
    
    return {
        'positiveScore': float(positive),
        'negativeScore': float(negative),
        'neutralScore': float(neutral),
        'confidenceScore': float(min(confidence, 1.0))
    }

def detect_biases(text):
    """Detect cognitive biases using ML model + pattern matching"""
    biases = []
    sentences = sent_tokenize(text)
    
    # ML-based detection if model is available
    if ML_MODEL and ML_VECTORIZER:
        try:
            for sentence in sentences:
                if len(sentence.strip()) < 10:
                    continue
                
                sentence_tfidf = ML_VECTORIZER.transform([sentence])
                prediction = ML_MODEL.predict(sentence_tfidf)[0]
                probabilities = ML_MODEL.predict_proba(sentence_tfidf)[0]
                confidence = float(max(probabilities))
                
                if prediction != 'none' and confidence > 0.4:
                    bias_type_map = {
                        'confirmation': 'Confirmation Bias',
                        'negativity': 'Negativity Bias',
                        'anchoring': 'Anchoring Bias',
                        'availability': 'Availability Bias'
                    }
                    biases.append({
                        'type': bias_type_map.get(prediction, prediction.title() + ' Bias'),
                        'evidence': sentence.strip(),
                        'confidence': confidence
                    })
        except Exception as e:
            print(f"ML prediction error: {e}")
    
    # Pattern-based detection (backup/supplement)
    for sentence in sentences:
        sentence_lower = sentence.lower()
        ml_detected = any(b['evidence'] == sentence.strip() and b['confidence'] > 0.7 for b in biases)
        if ml_detected:
            continue
        
        for pattern in BIAS_PATTERNS['confirmation']:
            if re.search(pattern, sentence_lower):
                biases.append({'type': 'Confirmation Bias', 'evidence': sentence.strip(), 'confidence': 0.75})
                break
        
        for pattern in BIAS_PATTERNS['negativity']:
            if re.search(pattern, sentence_lower):
                biases.append({'type': 'Negativity Bias', 'evidence': sentence.strip(), 'confidence': 0.80})
                break
    
    return biases

def extract_topics(text, num_topics=3):
    """Extract topics using simple frequency analysis"""
    tokens = preprocess_text(text)
    
    if len(tokens) < 5:
        return []
    
    # Count word frequencies
    word_freq = Counter(tokens)
    most_common = word_freq.most_common(num_topics * 2)
    
    topics = []
    for i in range(0, min(len(most_common), num_topics * 2), 2):
        if i + 1 < len(most_common):
            topic_words = [most_common[i][0], most_common[i+1][0]]
            topic_name = ' '.join(topic_words).title()
            
            # Calculate bias scores based on sentiment
            sentiment = analyze_sentiment(' '.join([w for w, _ in most_common[i:i+2]]))
            
            topics.append({
                'topic': topic_name,
                'confirmationBias': float(random.uniform(0.1, 0.6)),
                'negativityBias': float(sentiment['negativeScore']),
                'neutral': float(sentiment['neutralScore']),
                'biasScore': float(sentiment['negativeScore'] + 0.2)
            })
    
    return topics[:num_topics]

def mine_association_rules(text):
    """Mine association rules from text patterns"""
    sentences = sent_tokenize(text)
    
    if len(sentences) < 2:
        return []
    
    # Extract word pairs
    rules = []
    word_pairs = []
    
    for sentence in sentences:
        words = preprocess_text(sentence)
        if len(words) >= 2:
            for i in range(len(words) - 1):
                word_pairs.append((words[i], words[i+1]))
    
    # Count frequencies
    pair_counts = Counter(word_pairs)
    most_common = pair_counts.most_common(5)
    
    total_pairs = len(word_pairs)
    for (word1, word2), count in most_common:
        if count >= 2 and total_pairs > 0:
            support = count / total_pairs
            confidence = min(0.95, count / total_pairs + 0.3)
            
            rules.append({
                'antecedent': word1,
                'consequent': word2,
                'support': float(support),
                'confidence': float(confidence),
                'lift': float(random.uniform(1.2, 2.5))
            })
    
    return rules

@app.route('/api/analyze', methods=['POST'])
def analyze():
    """Main analysis endpoint"""
    try:
        data = request.get_json()
        text = data.get('text', '')
        
        if not text:
            return jsonify({'error': 'No text provided'}), 400
        
        # Perform analysis
        sentiment = analyze_sentiment(text)
        biases = detect_biases(text)
        topics = extract_topics(text)
        rules = mine_association_rules(text)
        
        # Preprocessing info
        tokens = preprocess_text(text)
        sentences = sent_tokenize(text)
        
        # Determine main sentiment
        max_sentiment = max(sentiment.items(), key=lambda x: x[1])
        sentiment_label = max_sentiment[0].replace('Score', '').capitalize()
        
        result = {
            'sentiment': sentiment,
            'bias': biases,
            'topicAnalysis': topics,
            'rules': rules,
            'preprocessing': {
                'tokenCount': len(tokens),
                'uniqueTokens': len(set(tokens)),
                'sentenceCount': len(sentences)
            },
            'mainTopic': topics[0]['topic'] if topics else 'General Discussion',
            'executiveSummary': f"ML Analysis detected {len(biases)} potential cognitive biases across {len(topics)} main topics. Overall sentiment is {sentiment_label} with {sentiment[max_sentiment[0]]*100:.1f}% confidence."
        }
        
        return jsonify(result)
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/health', methods=['GET'])
def health():
    """Health check endpoint"""
    model_status = 'loaded' if ML_MODEL is not None else 'not_loaded'
    return jsonify({'status': 'healthy', 'service': 'ML Bias Detection', 'version': '2.0', 'ml_model': model_status})

@app.route('/api/model/metrics', methods=['GET'])
def model_metrics():
    """Get ML model training metrics"""
    if ML_METRICS:
        return jsonify(ML_METRICS)
    return jsonify({'error': 'Model not trained', 'message': 'Run train_model.py to train the model'}), 404

@app.route('/api/health_old', methods=['GET'])
def health_old():
    """Old health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'ML Bias Detection', 'version': '1.0'})

if __name__ == '__main__':
    print("=" * 60)
    print("Starting ML Backend Server...")
    print("=" * 60)
    print("\nDownloading required NLTK data...")
    
    # Download required NLTK data
    try:
        nltk.download('vader_lexicon', quiet=True)
        nltk.download('punkt', quiet=True)
        nltk.download('punkt_tab', quiet=True)
        nltk.download('stopwords', quiet=True)
        nltk.download('wordnet', quiet=True)
        print("✓ NLTK data ready!")
    except Exception as e:
        print(f"⚠ Warning: Could not download NLTK data: {e}")
        print("  Some features may not work optimally.")
    
    # Load ML model
    print("\nLoading ML model...")
    load_ml_model()
    
    print("\n" + "=" * 60)
    print("🚀 Server starting on http://localhost:5000")
    print("=" * 60)
    print("\nEndpoints:")
    print("  POST /api/analyze        - Analyze text for biases")
    print("  GET  /api/health         - Health check")
    print("  GET  /api/model/metrics  - Get model performance metrics")
    print("\nPress CTRL+C to stop the server")
    print("=" * 60 + "\n")
    
    app.run(debug=True, port=5000, host='0.0.0.0')

