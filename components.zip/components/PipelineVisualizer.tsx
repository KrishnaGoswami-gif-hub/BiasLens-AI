import React, { useEffect, useState } from 'react';
import { FileText, Scissors, Brain, Network, Monitor, Globe } from 'lucide-react';

interface Props {
  isProcessing?: boolean;
}

const PipelineVisualizer: React.FC<Props> = ({ isProcessing = false }) => {
  const [activeStep, setActiveStep] = useState(0);

  useEffect(() => {
    if (!isProcessing) {
        setActiveStep(0);
        return;
    }
    
    // Cycle through steps to simulate the pipeline
    // 0: Client -> Gateway
    // 1: Gateway -> NLP
    // 2: NLP -> Logic
    // 3: Logic -> Mining
    // 4: Mining -> Client (Complete)
    const interval = setInterval(() => {
      setActiveStep((prev) => (prev + 1) % 5);
    }, 800);

    return () => clearInterval(interval);
  }, [isProcessing]);

  // Visual nodes configuration for 3D positioning
  // Positions are relative percentages on the 3D plane
  const nodes = [
    { id: 'client', title: 'Client Input', icon: Monitor, color: 'blue', x: 10, y: 50, z: 0, zone: 'client' },
    { id: 'gateway', title: 'API Gateway', icon: Globe, color: 'indigo', x: 40, y: 50, z: 20, zone: 'network' },
    { id: 'nlp', title: 'NLP Engine', icon: Scissors, color: 'violet', x: 70, y: 20, z: 30, zone: 'server' },
    { id: 'logic', title: 'Bias Logic', icon: Brain, color: 'fuchsia', x: 70, y: 50, z: 30, zone: 'server' },
    { id: 'mining', title: 'Rule Mining', icon: Network, color: 'pink', x: 70, y: 80, z: 30, zone: 'server' }
  ];

  // Helper to highlight nodes based on the current step sequence
  const getActiveNode = (step: number) => {
      switch(step) {
          case 0: return 'client';
          case 1: return 'gateway';
          case 2: return 'nlp';
          case 3: return 'logic';
          case 4: return 'mining';
          default: return '';
      }
  }

  return (
    <div className="w-full h-[400px] mb-8 relative bg-slate-900 rounded-3xl overflow-hidden shadow-2xl shadow-slate-900/50 border border-slate-700 select-none group">
        
        {/* Animated Background Grid to give a sense of infinite digital space */}
        <div className="absolute inset-0 perspective-grid opacity-20 pointer-events-none"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent pointer-events-none"></div>

        <style>{`
          .perspective-grid {
             background-image: 
               linear-gradient(rgba(99, 102, 241, 0.3) 1px, transparent 1px),
               linear-gradient(90deg, rgba(99, 102, 241, 0.3) 1px, transparent 1px);
             background-size: 60px 60px;
             transform: perspective(600px) rotateX(60deg) scale(2);
             animation: grid-move 20s linear infinite;
             transform-origin: center top;
          }
          @keyframes grid-move {
             0% { background-position: 0 0; }
             100% { background-position: 0 60px; }
          }
          .iso-scene {
             transform: rotateX(60deg) rotateZ(-45deg) scale(0.95);
             transform-style: preserve-3d;
          }
          .node-plate {
             transform-style: preserve-3d;
             transition: transform 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
          }
          .node-plate.active {
             transform: translateZ(40px);
          }
          .pulse-ring {
             animation: pulse-ring 1.5s cubic-bezier(0.215, 0.61, 0.355, 1) infinite;
          }
          @keyframes pulse-ring {
             0% { transform: scale(0.8); opacity: 1; }
             100% { transform: scale(2.2); opacity: 0; }
          }
        `}</style>

        {/* 3D Scene Container */}
        <div className="absolute inset-0 flex items-center justify-center perspective-[1200px]">
            <div className="relative w-[600px] h-[600px] iso-scene">
                
                {/* === ZONES === */}
                
                {/* Client Zone Base */}
                <div className="absolute left-[2%] top-[42%] w-[16%] h-[16%] bg-blue-500/5 border border-blue-500/20 rounded-full transform translateZ(-10px) shadow-[0_0_40px_rgba(59,130,246,0.1)]">
                    <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 text-[10px] font-bold text-blue-400/60 whitespace-nowrap tracking-[0.2em] uppercase transform -rotateZ(-45deg) -rotateX(60deg) translateZ(10px)">Client Side</div>
                </div>

                {/* Server Zone Base */}
                <div className="absolute left-[60%] top-[10%] w-[30%] h-[80%] bg-indigo-500/5 border border-indigo-500/20 rounded-3xl transform translateZ(-20px) shadow-[0_0_60px_rgba(99,102,241,0.1)]">
                     <div className="absolute -right-16 top-1/2 -translate-y-1/2 text-[10px] font-bold text-indigo-400/60 whitespace-nowrap tracking-[0.2em] uppercase transform rotateZ(90deg) -rotateX(60deg) translateZ(10px) origin-left">Server Cluster</div>
                </div>

                {/* Connecting Path Lines (SVG overlay on the 3D plane) */}
                <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible" style={{ transform: 'translateZ(-5px)' }}>
                    <defs>
                        <linearGradient id="pathGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
                            <stop offset="100%" stopColor="#ec4899" stopOpacity="0.4" />
                        </linearGradient>
                        <filter id="glow">
                            <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
                            <feMerge>
                                <feMergeNode in="coloredBlur"/>
                                <feMergeNode in="SourceGraphic"/>
                            </feMerge>
                        </filter>
                    </defs>
                    
                    {/* Path Traces */}
                    <path d="M 90 300 L 240 300" stroke="url(#pathGradient)" strokeWidth="2" fill="none" /> {/* Client to Gateway */}
                    <path d="M 240 300 L 420 120" stroke="url(#pathGradient)" strokeWidth="2" fill="none" /> {/* Gateway to NLP */}
                    <path d="M 240 300 L 420 300" stroke="url(#pathGradient)" strokeWidth="2" fill="none" /> {/* Gateway to Logic */}
                    <path d="M 240 300 L 420 480" stroke="url(#pathGradient)" strokeWidth="2" fill="none" /> {/* Gateway to Mining */}

                    {/* Animated Data Packets */}
                    {isProcessing && (
                        <>
                            {/* Packet 1: To NLP */}
                            <circle r="4" fill="#fff" filter="url(#glow)">
                                <animateMotion 
                                   dur="2s" 
                                   repeatCount="indefinite"
                                   path="M 90 300 L 240 300 L 420 120"
                                   keyPoints="0;1"
                                   keyTimes="0;1"
                                   calcMode="linear"
                                />
                            </circle>
                            {/* Packet 2: To Logic (Delayed) */}
                            <circle r="4" fill="#fff" filter="url(#glow)">
                                <animateMotion 
                                   dur="2s" 
                                   begin="0.5s"
                                   repeatCount="indefinite"
                                   path="M 90 300 L 240 300 L 420 300"
                                />
                            </circle>
                             {/* Packet 3: To Mining (Delayed) */}
                             <circle r="4" fill="#fff" filter="url(#glow)">
                                <animateMotion 
                                   dur="2s" 
                                   begin="1s"
                                   repeatCount="indefinite"
                                   path="M 90 300 L 240 300 L 420 480"
                                />
                            </circle>
                        </>
                    )}
                </svg>

                {/* 3D Isometric Nodes */}
                {nodes.map((node) => {
                    const isActive = getActiveNode(activeStep) === node.id && isProcessing;
                    
                    return (
                        <div 
                            key={node.id}
                            className={`absolute w-20 h-20 node-plate ${isActive ? 'active' : ''}`}
                            style={{ 
                                left: `${node.x}%`, 
                                top: `${node.y}%`, 
                                marginTop: '-40px', 
                                marginLeft: '-40px', 
                                zIndex: Math.floor(node.z) + 10 
                            }}
                        >
                            {/* Drop Shadow */}
                            <div className="absolute inset-0 bg-black/60 blur-xl rounded-full transform translateZ(-30px) scale-75 opacity-60"></div>
                            
                            {/* Glass Block Body */}
                            <div className={`
                                relative w-full h-full rounded-2xl backdrop-blur-md border border-white/10 
                                flex flex-col items-center justify-center transition-all duration-500 ease-out
                                ${isActive 
                                    ? `bg-${node.color}-500/90 shadow-[0_0_50px_rgba(255,255,255,0.3)] border-white/60` 
                                    : `bg-slate-800/80 hover:bg-slate-700/80`
                                }
                            `}>
                                {/* Reflective Sheen */}
                                <div className="absolute inset-x-0 top-0 h-1/2 bg-gradient-to-b from-white/20 to-transparent rounded-t-2xl pointer-events-none"></div>
                                
                                <node.icon className={`w-8 h-8 z-10 transition-all duration-300 ${isActive ? 'text-white scale-110' : `text-${node.color}-400 opacity-80`}`} />
                                
                                {isActive && (
                                    <div className="absolute inset-0 rounded-2xl ring-4 ring-white/30 pulse-ring"></div>
                                )}
                            </div>

                            {/* Floating 3D Label */}
                            <div className="absolute -top-10 left-1/2 -translate-x-1/2 whitespace-nowrap transform -rotateZ(-45deg) -rotateX(60deg) translateZ(60px)">
                                <span className={`text-[10px] font-bold px-3 py-1.5 rounded-full backdrop-blur-md border transition-all duration-300 shadow-xl
                                    ${isActive 
                                        ? 'bg-white text-slate-900 border-white scale-110' 
                                        : 'bg-slate-900/80 text-slate-400 border-slate-700'
                                    }
                                `}>
                                    {node.title}
                                </span>
                            </div>
                        </div>
                    );
                })}

            </div>
        </div>

        {/* HUD Overlay - Status & Legend */}
        <div className="absolute bottom-6 left-6 flex flex-col gap-3">
            <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_12px_#3b82f6]"></div>
                <span className="text-xs text-blue-200/70 font-medium tracking-wide uppercase">Client Interface</span>
            </div>
            <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-indigo-500 shadow-[0_0_12px_#6366f1]"></div>
                <span className="text-xs text-indigo-200/70 font-medium tracking-wide uppercase">Processing Cloud</span>
            </div>
        </div>

        {/* Processing Indicator */}
        <div className="absolute top-6 right-8 text-right z-20">
             <div className="text-[10px] font-bold text-slate-500 mb-1 tracking-widest">PROCESS STATUS</div>
             <div className="flex items-center justify-end gap-3 p-2 bg-slate-800/50 backdrop-blur rounded-lg border border-slate-700">
                 <span className={`relative flex h-3 w-3`}>
                    {isProcessing && <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>}
                    <span className={`relative inline-flex rounded-full h-3 w-3 ${isProcessing ? 'bg-emerald-500' : 'bg-slate-500'}`}></span>
                 </span>
                 <span className={`text-sm font-bold tracking-tight ${isProcessing ? 'text-white' : 'text-slate-400'}`}>
                     {isProcessing ? 'ANALYZING PIPELINE...' : 'READY FOR INPUT'}
                 </span>
             </div>
        </div>

    </div>
  );
};

export default PipelineVisualizer;