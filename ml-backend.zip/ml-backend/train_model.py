"""
Training script for cognitive bias classification model.
Creates synthetic dataset, trains Naive Bayes classifier, and evaluates performance.
"""

import os
import json
import random
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score
import joblib

# Create models directory
os.makedirs('models', exist_ok=True)

# Synthetic training dataset
TRAINING_DATA = [
    # Confirmation Bias Examples
    ("Obviously, this is the only correct solution to the problem.", "confirmation"),
    ("Everyone knows that this approach always works best.", "confirmation"),
    ("It's clearly evident that my theory is undeniably true.", "confirmation"),
    ("All experts agree that this must be the right answer.", "confirmation"),
    ("This certainly proves my point beyond any doubt.", "confirmation"),
    ("Without question, this is the definitive answer.", "confirmation"),
    ("It's absolutely clear that I was right all along.", "confirmation"),
    ("The evidence obviously supports my initial hypothesis.", "confirmation"),
    ("Everyone can see that this is the only logical conclusion.", "confirmation"),
    ("This definitely confirms what I've been saying.", "confirmation"),
    ("All the data clearly shows I was correct.", "confirmation"),
    ("It's undeniable that my approach is superior.", "confirmation"),
    ("Obviously, anyone who disagrees is simply wrong.", "confirmation"),
    ("The facts clearly demonstrate my point.", "confirmation"),
    ("This certainly validates my original assumption.", "confirmation"),
    ("Without doubt, this proves I was right.", "confirmation"),
    ("Everyone must agree this is the best solution.", "confirmation"),
    ("It's perfectly clear that my method works.", "confirmation"),
    ("All evidence points to my conclusion being correct.", "confirmation"),
    ("This absolutely confirms my beliefs.", "confirmation"),
    
    # Negativity Bias Examples
    ("This is a complete disaster waiting to happen.", "negativity"),
    ("Everything will fail if we proceed with this plan.", "negativity"),
    ("This is the worst possible outcome imaginable.", "negativity"),
    ("The situation is absolutely hopeless and terrible.", "negativity"),
    ("This will inevitably lead to catastrophic failure.", "negativity"),
    ("It's a horrible idea that will destroy everything.", "negativity"),
    ("This crisis will ruin all our progress.", "negativity"),
    ("The risks are too dangerous to even consider.", "negativity"),
    ("This terrible decision will have awful consequences.", "negativity"),
    ("Everything is going to collapse if we do this.", "negativity"),
    ("This is an impossible task that will never work.", "negativity"),
    ("The whole project is doomed to fail.", "negativity"),
    ("This disastrous approach will cause major problems.", "negativity"),
    ("It's a threat to everything we've built.", "negativity"),
    ("This horrible situation keeps getting worse.", "negativity"),
    ("The outcome will be catastrophically bad.", "negativity"),
    ("This is the worst crisis we've ever faced.", "negativity"),
    ("Everything is falling apart and failing.", "negativity"),
    ("This terrible plan will destroy our chances.", "negativity"),
    ("The situation is hopeless and getting worse.", "negativity"),
    
    # Anchoring Bias Examples
    ("Compared to the initial estimate, this seems reasonable.", "anchoring"),
    ("The first price we saw was much higher.", "anchoring"),
    ("Originally, we thought it would cost twice as much.", "anchoring"),
    ("Relative to what we started with, this is better.", "anchoring"),
    ("The initial proposal was significantly different.", "anchoring"),
    ("When we first discussed this, the numbers were higher.", "anchoring"),
    ("Compared to the original plan, this is an improvement.", "anchoring"),
    ("The starting point was much more expensive.", "anchoring"),
    ("Initially, we were looking at a higher figure.", "anchoring"),
    ("Versus the first option, this seems more affordable.", "anchoring"),
    ("The original estimate was substantially larger.", "anchoring"),
    ("Compared to where we began, this is progress.", "anchoring"),
    ("The first number mentioned was quite different.", "anchoring"),
    ("Relative to the initial quote, this is acceptable.", "anchoring"),
    ("When we started, the cost was projected higher.", "anchoring"),
    ("The baseline we established was more expensive.", "anchoring"),
    ("Compared to the reference point, this works.", "anchoring"),
    ("The initial benchmark was set much higher.", "anchoring"),
    ("Originally, the target was significantly different.", "anchoring"),
    ("Versus the starting position, this is better.", "anchoring"),
    
    # Availability Bias Examples
    ("I just heard about this happening recently.", "availability"),
    ("Everyone's been talking about this lately.", "availability"),
    ("I saw on the news that this is common.", "availability"),
    ("This is obviously a widespread problem everyone knows about.", "availability"),
    ("Recently, there have been many cases of this.", "availability"),
    ("It's common knowledge that this happens frequently.", "availability"),
    ("I've been hearing about this everywhere lately.", "availability"),
    ("The media has been covering this extensively.", "availability"),
    ("Everyone I know has experienced this recently.", "availability"),
    ("This is clearly a trend based on recent events.", "availability"),
    ("I just read several articles about this issue.", "availability"),
    ("It's been all over social media recently.", "availability"),
    ("Everyone's aware of this because it's so common.", "availability"),
    ("I've seen multiple examples of this lately.", "availability"),
    ("Recent reports show this is happening everywhere.", "availability"),
    ("This is obviously widespread based on what I've seen.", "availability"),
    ("I keep hearing about this from different sources.", "availability"),
    ("It's become a well-known issue recently.", "availability"),
    ("Everyone knows this because it's been in the news.", "availability"),
    ("I've personally witnessed this happening multiple times.", "availability"),
    
    # Neutral Examples (No Bias)
    ("The data suggests there are multiple factors to consider.", "none"),
    ("We should analyze both the advantages and disadvantages.", "none"),
    ("Different perspectives offer valuable insights on this topic.", "none"),
    ("The research indicates mixed results that warrant further study.", "none"),
    ("There are several possible explanations for this phenomenon.", "none"),
    ("The evidence presents both supporting and contradicting information.", "none"),
    ("We need to examine all available options carefully.", "none"),
    ("The situation requires a balanced assessment of the facts.", "none"),
    ("Multiple studies have shown varying results on this issue.", "none"),
    ("It's important to consider alternative viewpoints.", "none"),
    ("The outcome depends on various contextual factors.", "none"),
    ("Further investigation is needed to draw conclusions.", "none"),
    ("There are trade-offs between different approaches.", "none"),
    ("The analysis reveals complexity in the underlying patterns.", "none"),
    ("We should evaluate the pros and cons objectively.", "none"),
    ("The findings suggest nuanced interpretations are possible.", "none"),
    ("Different methodologies yield different insights.", "none"),
    ("The situation presents both opportunities and challenges.", "none"),
    ("A comprehensive review of the evidence is necessary.", "none"),
    ("The data shows variability across different conditions.", "none"),
    ("We can explore several potential solutions.", "none"),
    ("The research methodology affects the interpretation.", "none"),
    ("Context plays an important role in understanding this.", "none"),
    ("There are limitations to the current understanding.", "none"),
    ("The topic benefits from interdisciplinary perspectives.", "none"),
    ("We should consider the broader implications carefully.", "none"),
    ("The evidence base continues to evolve.", "none"),
    ("Multiple factors interact in complex ways.", "none"),
    ("The findings warrant careful interpretation.", "none"),
    ("Different stakeholders have varying priorities.", "none"),
]

# Expand dataset with variations
def generate_variations(text, label, num_variations=3):
    """Generate slight variations of training examples"""
    variations = [(text, label)]
    
    # Add some simple variations
    if "this" in text.lower():
        variations.append((text.replace("this", "that"), label))
    if "is" in text.lower():
        variations.append((text.replace("is", "seems"), label))
    
    return variations[:num_variations]

# Expand training data
expanded_data = []
for text, label in TRAINING_DATA:
    expanded_data.extend(generate_variations(text, label, 2))

# Add more synthetic examples
random.seed(42)
for _ in range(50):
    # Generate more confirmation bias examples
    templates = [
        "It's {adv} {adj} that {statement}",
        "{adv}, {statement}",
        "All {group} {verb} that {statement}",
    ]
    adverbs = ["obviously", "clearly", "certainly", "definitely", "undeniably"]
    adjectives = ["clear", "evident", "obvious", "certain", "true"]
    groups = ["experts", "people", "researchers", "studies", "data"]
    verbs = ["show", "prove", "demonstrate", "confirm", "indicate"]
    statements = ["this is correct", "the theory holds", "the approach works", "the results are valid"]
    
    template = random.choice(templates)
    if "{adv}" in template:
        text = template.format(
            adv=random.choice(adverbs),
            adj=random.choice(adjectives),
            statement=random.choice(statements),
            group=random.choice(groups),
            verb=random.choice(verbs)
        )
        expanded_data.append((text, "confirmation"))

print(f"Total training examples: {len(expanded_data)}")

# Prepare data
texts = [text for text, _ in expanded_data]
labels = [label for _, label in expanded_data]

# Split data
X_train, X_test, y_train, y_test = train_test_split(
    texts, labels, test_size=0.2, random_state=42, stratify=labels
)

print(f"Training samples: {len(X_train)}")
print(f"Test samples: {len(X_test)}")

# Create TF-IDF vectorizer
vectorizer = TfidfVectorizer(
    max_features=5000,
    ngram_range=(1, 2),
    min_df=2,
    sublinear_tf=True
)

# Fit and transform training data
X_train_tfidf = vectorizer.fit_transform(X_train)
X_test_tfidf = vectorizer.transform(X_test)

print(f"Feature matrix shape: {X_train_tfidf.shape}")

# Train Naive Bayes classifier
clf = MultinomialNB(alpha=0.1)
clf.fit(X_train_tfidf, y_train)

# Predictions
y_pred = clf.predict(X_test_tfidf)

# Evaluation
accuracy = accuracy_score(y_test, y_pred)
print(f"\n{'='*60}")
print(f"Model Accuracy: {accuracy:.2%}")
print(f"{'='*60}\n")

# Classification report
print("Classification Report:")
print(classification_report(y_test, y_pred))

# Confusion matrix
print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))

# Cross-validation
cv_scores = cross_val_score(clf, X_train_tfidf, y_train, cv=5)
print(f"\nCross-validation scores: {cv_scores}")
print(f"Mean CV accuracy: {cv_scores.mean():.2%} (+/- {cv_scores.std() * 2:.2%})")

# Save model and vectorizer
joblib.dump(clf, 'models/bias_classifier.pkl')
joblib.dump(vectorizer, 'models/tfidf_vectorizer.pkl')

# Save metrics
metrics = {
    'accuracy': float(accuracy),
    'cv_mean': float(cv_scores.mean()),
    'cv_std': float(cv_scores.std()),
    'training_samples': len(X_train),
    'test_samples': len(X_test),
    'features': X_train_tfidf.shape[1]
}

with open('models/training_metrics.json', 'w') as f:
    json.dump(metrics, f, indent=2)

print(f"\n{'='*60}")
print("✓ Model saved to models/bias_classifier.pkl")
print("✓ Vectorizer saved to models/tfidf_vectorizer.pkl")
print("✓ Metrics saved to models/training_metrics.json")
print(f"{'='*60}\n")
