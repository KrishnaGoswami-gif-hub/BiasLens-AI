import React from 'react';
import { AIModel } from '../types';
import { Brain, Sparkles, GitCompare } from 'lucide-react';

interface ModelSelectorProps {
  selectedModel: AIModel;
  onModelChange: (model: AIModel) => void;
  disabled?: boolean;
}

const ModelSelector: React.FC<ModelSelectorProps> = ({ selectedModel, onModelChange, disabled = false }) => {
  const models = [
    {
      id: 'gemini' as AIModel,
      name: 'Gemini AI',
      icon: Sparkles,
      description: 'Fast & structured analysis',
      selectedBg: 'bg-indigo-50',
      selectedBorder: 'border-indigo-500',
      selectedRing: 'ring-indigo-500',
      selectedIconBg: 'bg-indigo-100',
      selectedIconColor: 'text-indigo-600',
      selectedTextColor: 'text-indigo-900',
      selectedDot: 'bg-indigo-500',
    },
    {
      id: 'deepseek' as AIModel,
      name: 'DeepSeek AI',
      icon: Brain,
      description: 'Deep reasoning & insights',
      selectedBg: 'bg-violet-50',
      selectedBorder: 'border-violet-500',
      selectedRing: 'ring-violet-500',
      selectedIconBg: 'bg-violet-100',
      selectedIconColor: 'text-violet-600',
      selectedTextColor: 'text-violet-900',
      selectedDot: 'bg-violet-500',
    },
    {
      id: 'dual' as AIModel,
      name: 'Dual Analysis',
      icon: GitCompare,
      description: 'Compare both models',
      selectedBg: 'bg-purple-50',
      selectedBorder: 'border-purple-500',
      selectedRing: 'ring-purple-500',
      selectedIconBg: 'bg-purple-100',
      selectedIconColor: 'text-purple-600',
      selectedTextColor: 'text-purple-900',
      selectedDot: 'bg-purple-500',
    },
  ];

  return (
    <div className="mb-6">
      <label className="block text-sm font-bold text-slate-700 mb-3">
        AI Model Selection
      </label>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {models.map((model) => {
          const Icon = model.icon;
          const isSelected = selectedModel === model.id;
          
          return (
            <button
              key={model.id}
              onClick={() => !disabled && onModelChange(model.id)}
              disabled={disabled}
              className={`
                relative p-4 rounded-xl border-2 transition-all duration-200
                ${isSelected
                  ? `${model.selectedBorder} ${model.selectedBg} ring-2 ${model.selectedRing}`
                  : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                }
                ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}
              `}
            >
              <div className="flex items-start gap-3">
                <div className={`
                  p-2 rounded-lg
                  ${isSelected ? model.selectedIconBg : 'bg-slate-100'}
                `}>
                  <Icon className={`
                    w-5 h-5
                    ${isSelected ? model.selectedIconColor : 'text-slate-600'}
                  `} />
                </div>
                <div className="flex-1 text-left">
                  <div className={`
                    font-bold text-sm mb-1
                    ${isSelected ? model.selectedTextColor : 'text-slate-800'}
                  `}>
                    {model.name}
                  </div>
                  <div className="text-xs text-slate-500">
                    {model.description}
                  </div>
                </div>
                {isSelected && (
                  <div className={`absolute top-2 right-2 w-2 h-2 rounded-full ${model.selectedDot}`} />
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default ModelSelector;
