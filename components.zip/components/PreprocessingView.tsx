import React from 'react';
import { PreprocessingData } from '../types';
import { Filter, Scissors, ArrowRight } from 'lucide-react';

interface Props {
  data: PreprocessingData;
}

const PreprocessingView: React.FC<Props> = ({ data }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
      <h3 className="text-lg font-semibold text-slate-800 mb-6 flex items-center gap-2">
        <Filter className="w-5 h-5 text-indigo-500" />
        Data Preprocessing Pipeline
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 relative">
        {/* Step 1 */}
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-100 relative">
            <div className="absolute -right-3 top-1/2 -translate-y-1/2 z-10 hidden md:block">
                <ArrowRight className="w-6 h-6 text-slate-300" />
            </div>
            <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-slate-500">Step 1</span>
                <Scissors className="w-4 h-4 text-slate-400" />
            </div>
            <div className="font-bold text-2xl text-slate-800">{data.originalTokenCount}</div>
            <div className="text-sm text-slate-600">Raw Tokens</div>
        </div>

        {/* Step 2 */}
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-100 relative">
             <div className="absolute -right-3 top-1/2 -translate-y-1/2 z-10 hidden md:block">
                <ArrowRight className="w-6 h-6 text-slate-300" />
            </div>
            <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-slate-500">Step 2</span>
                <Filter className="w-4 h-4 text-slate-400" />
            </div>
            <div className="font-bold text-2xl text-indigo-600">{data.removedStopwords.length}</div>
            <div className="text-sm text-slate-600">Stopwords Removed</div>
            <div className="mt-2 flex flex-wrap gap-1">
                {data.removedStopwords.slice(0, 5).map((word, i) => (
                    <span key={i} className="text-xs bg-red-100 text-red-600 px-1.5 py-0.5 rounded line-through opacity-70">
                        {word}
                    </span>
                ))}
                 {data.removedStopwords.length > 5 && (
                    <span className="text-xs text-slate-400 px-1.5 py-0.5">...</span>
                )}
            </div>
        </div>

        {/* Step 3 */}
        <div className="bg-slate-50 rounded-lg p-4 border border-slate-100">
            <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-slate-500">Step 3</span>
                <span className="text-xs px-2 py-0.5 bg-green-100 text-green-700 rounded-full">Ready</span>
            </div>
            <div className="font-bold text-2xl text-green-600">{data.cleanedTokenCount}</div>
            <div className="text-sm text-slate-600">Cleaned Tokens</div>
             <div className="mt-2 flex flex-wrap gap-1">
                {data.lemmatizedTokens.slice(0, 4).map((word, i) => (
                    <span key={i} className="text-xs bg-white border border-slate-200 text-slate-600 px-1.5 py-0.5 rounded shadow-sm">
                        {word}
                    </span>
                ))}
            </div>
        </div>
      </div>
    </div>
  );
};

export default PreprocessingView;
