import React from 'react';
import { AnalysisResult, DeepSeekAnalysisResult } from '../types';
import { ArrowRight, TrendingUp, TrendingDown } from 'lucide-react';
import PreprocessingView from './PreprocessingView';
import SentimentBiasView from './SentimentBiasView';
import AssociationRulesView from './AssociationRulesView';
import TopicBiasHeatmap from './TopicBiasHeatmap';
import ReasoningDisplay from './ReasoningDisplay';

interface DualAnalysisViewProps {
  geminiResult: AnalysisResult;
  deepseekResult: DeepSeekAnalysisResult;
}

const DualAnalysisView: React.FC<DualAnalysisViewProps> = ({ geminiResult, deepseekResult }) => {
  // Calculate comparison metrics
  const sentimentDiff = Math.abs(geminiResult.sentiment.score - deepseekResult.sentiment.score);
  
  // Count bias agreement
  const geminiBiasTypes = new Set(geminiResult.bias.map(b => b.type));
  const deepseekBiasTypes = new Set(deepseekResult.bias.map(b => b.type));
  const commonBiases = [...geminiBiasTypes].filter(type => deepseekBiasTypes.has(type));
  const biasAgreement = commonBiases.length / Math.max(geminiBiasTypes.size, deepseekBiasTypes.size, 1);

  return (
    <div className="space-y-8">
      {/* Comparison Summary */}
      <div className="bg-gradient-to-br from-purple-900 to-indigo-900 rounded-2xl p-8 text-white shadow-xl">
        <h2 className="text-2xl font-bold mb-4">Dual Model Analysis Comparison</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white/10 backdrop-blur rounded-lg p-4">
            <div className="text-sm text-purple-200 mb-1">Model Agreement</div>
            <div className="text-3xl font-bold">{(biasAgreement * 100).toFixed(0)}%</div>
            <div className="text-xs text-purple-300 mt-1">
              {commonBiases.length} common bias{commonBiases.length !== 1 ? 'es' : ''} detected
            </div>
          </div>
          <div className="bg-white/10 backdrop-blur rounded-lg p-4">
            <div className="text-sm text-purple-200 mb-1">Sentiment Difference</div>
            <div className="text-3xl font-bold">{sentimentDiff.toFixed(2)}</div>
            <div className="text-xs text-purple-300 mt-1">
              {sentimentDiff < 0.2 ? 'High agreement' : sentimentDiff < 0.5 ? 'Moderate difference' : 'Significant difference'}
            </div>
          </div>
        </div>
      </div>

      {/* DeepSeek Reasoning */}
      <ReasoningDisplay reasoning={deepseekResult.reasoning} />

      {/* Side-by-side Executive Summaries */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-gradient-to-br from-indigo-50 to-blue-50 rounded-xl p-6 border border-indigo-200">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-3 h-3 rounded-full bg-indigo-500"></div>
            <h3 className="font-bold text-indigo-900">Gemini Analysis</h3>
          </div>
          <p className="text-sm text-slate-700 leading-relaxed">
            {geminiResult.executiveSummary}
          </p>
          <div className="mt-4 flex items-center gap-2">
            {geminiResult.sentiment.label === 'Positive' && <TrendingUp className="w-4 h-4 text-green-600" />}
            {geminiResult.sentiment.label === 'Negative' && <TrendingDown className="w-4 h-4 text-red-600" />}
            <span className="text-xs font-semibold text-slate-600">
              {geminiResult.sentiment.label} ({geminiResult.sentiment.score.toFixed(2)})
            </span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-violet-50 to-purple-50 rounded-xl p-6 border border-violet-200">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-3 h-3 rounded-full bg-violet-500"></div>
            <h3 className="font-bold text-violet-900">DeepSeek Analysis</h3>
          </div>
          <p className="text-sm text-slate-700 leading-relaxed">
            {deepseekResult.executiveSummary}
          </p>
          <div className="mt-4 flex items-center gap-2">
            {deepseekResult.sentiment.label === 'Positive' && <TrendingUp className="w-4 h-4 text-green-600" />}
            {deepseekResult.sentiment.label === 'Negative' && <TrendingDown className="w-4 h-4 text-red-600" />}
            <span className="text-xs font-semibold text-slate-600">
              {deepseekResult.sentiment.label} ({deepseekResult.sentiment.score.toFixed(2)})
            </span>
          </div>
        </div>
      </div>

      {/* Detailed Comparison Sections */}
      <div className="space-y-8">
        <div>
          <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
            <ArrowRight className="w-5 h-5 text-indigo-600" />
            Sentiment & Bias Comparison
          </h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="text-sm font-semibold text-indigo-600 mb-2">Gemini</div>
              <SentimentBiasView data={geminiResult} />
            </div>
            <div>
              <div className="text-sm font-semibold text-violet-600 mb-2">DeepSeek</div>
              <SentimentBiasView data={deepseekResult} />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
            <ArrowRight className="w-5 h-5 text-indigo-600" />
            Topic Analysis Comparison
          </h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="text-sm font-semibold text-indigo-600 mb-2">Gemini</div>
              <TopicBiasHeatmap data={geminiResult.topicAnalysis} />
            </div>
            <div>
              <div className="text-sm font-semibold text-violet-600 mb-2">DeepSeek</div>
              <TopicBiasHeatmap data={deepseekResult.topicAnalysis} />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-bold text-slate-800 mb-4 flex items-center gap-2">
            <ArrowRight className="w-5 h-5 text-indigo-600" />
            Association Rules Comparison
          </h3>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="text-sm font-semibold text-indigo-600 mb-2">Gemini</div>
              <AssociationRulesView data={geminiResult} />
            </div>
            <div>
              <div className="text-sm font-semibold text-violet-600 mb-2">DeepSeek</div>
              <AssociationRulesView data={deepseekResult} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DualAnalysisView;
