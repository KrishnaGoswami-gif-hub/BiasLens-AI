chrome.runtime.onInstalled.addListener(() => {
    chrome.contextMenus.create({
        id: "cbie-analyze-bias",
        title: "🧠 CBIE: Check for Cognitive Bias",
        contexts: ["selection"]
    });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
    if (info.menuItemId === "cbie-analyze-bias") {
        // Send a message to the content script in the active tab
        chrome.tabs.sendMessage(tab.id, {
            action: "analyze_selection",
            text: info.selectionText
        });
    }
});
