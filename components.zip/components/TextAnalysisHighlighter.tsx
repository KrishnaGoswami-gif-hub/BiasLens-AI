import React from 'react';
import { BiasIndicator } from '../types';
import { Search } from 'lucide-react';

interface Props {
  text: string;
  biasData: BiasIndicator[];
}

const TextAnalysisHighlighter: React.FC<Props> = ({ text, biasData }) => {
  // Flatten all triggers into a single array for easier checking
  const confirmationTriggers = biasData
    .filter(b => b.type === 'Confirmation Bias')
    .flatMap(b => b.triggers.map(t => t.toLowerCase()));

  const negativityTriggers = biasData
    .filter(b => b.type === 'Negativity Bias')
    .flatMap(b => b.triggers.map(t => t.toLowerCase()));

  const getHighlightClass = (word: string) => {
    const cleanWord = word.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (!cleanWord) return '';

    if (confirmationTriggers.some(t => cleanWord.includes(t) || t.includes(cleanWord))) {
      return 'bg-blue-100 text-blue-800 border-b-2 border-blue-400 cursor-help';
    }
    if (negativityTriggers.some(t => cleanWord.includes(t) || t.includes(cleanWord))) {
      return 'bg-red-100 text-red-800 border-b-2 border-red-400 cursor-help';
    }
    return '';
  };

  const getTooltip = (word: string) => {
    const cleanWord = word.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (confirmationTriggers.some(t => cleanWord.includes(t))) return 'Confirmation Bias Indicator: Absolutist language used to reinforce a belief.';
    if (negativityTriggers.some(t => cleanWord.includes(t))) return 'Negativity Bias Indicator: Emotionally charged negative language.';
    return '';
  };

  return (
    <div className="bg-white rounded-xl shadow-lg border border-indigo-100 overflow-hidden">
      <div className="bg-gradient-to-r from-slate-50 to-white px-6 py-4 border-b border-slate-100 flex justify-between items-center">
        <h3 className="font-semibold text-slate-800 flex items-center gap-2">
            <Search className="w-4 h-4 text-indigo-500" />
            Explainable Text Analysis
        </h3>
        <div className="flex gap-4 text-xs">
            <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 bg-blue-100 border-b-2 border-blue-400 rounded-sm"></span>
                <span className="text-slate-600">Confirmation Trigger</span>
            </div>
            <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 bg-red-100 border-b-2 border-red-400 rounded-sm"></span>
                <span className="text-slate-600">Negativity Trigger</span>
            </div>
        </div>
      </div>
      
      <div className="p-6 text-sm leading-relaxed text-slate-700 font-mono">
        {text.split(/(\s+)/).map((part, index) => {
           const highlight = getHighlightClass(part);
           const tooltip = getTooltip(part);
           
           if (highlight) {
               return (
                   <span key={index} className={`relative group px-0.5 rounded-sm transition-colors ${highlight}`}>
                       {part}
                       {/* Tooltip */}
                       <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-slate-800 text-white text-xs rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 text-center font-sans">
                           {tooltip}
                           <svg className="absolute text-slate-800 h-2 w-full left-0 top-full" x="0px" y="0px" viewBox="0 0 255 255"><polygon className="fill-current" points="0,0 127.5,127.5 255,0"/></svg>
                       </span>
                   </span>
               );
           }
           return <span key={index}>{part}</span>;
        })}
      </div>
      
      <div className="bg-slate-50 px-6 py-3 text-xs text-slate-500 border-t border-slate-100 flex items-center gap-2">
         <span className="font-semibold">Why this matters:</span> Highlighting reveals exactly which words the algorithm flagged as biased, making the "black box" transparent.
      </div>
    </div>
  );
};

export default TextAnalysisHighlighter;