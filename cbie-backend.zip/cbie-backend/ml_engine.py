import os
import re
import joblib
import json
import nltk
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from textblob import TextBlob
from nltk.tokenize import word_tokenize, sent_tokenize
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
from collections import Counter
import random

# Ensure NLTK data is downloaded
try:
    nltk.download('vader_lexicon', quiet=True)
    nltk.download('punkt', quiet=True)
    nltk.download('stopwords', quiet=True)
    nltk.download('wordnet', quiet=True)
except Exception:
    pass

class CognitiveBiasModel:
    def __init__(self):
        self.vader_analyzer = SentimentIntensityAnalyzer()
        self.lemmatizer = WordNetLemmatizer()
        try:
            self.stop_words = set(stopwords.words('english'))
        except:
            self.stop_words = set()

        self.model = None
        self.vectorizer = None
        self._load_models()

        self.bias_patterns = {
            'confirmation': [r'\b(always|never|everyone|no one|all|none)\b', r'\b(obviously|clearly|undeniably|certainly)\b'],
            'negativity': [r'\b(disaster|catastrophe|horrible|terrible|awful)\b', r'\b(fail|failure|destroy|ruin|doom)\b'],
        }

    def _load_models(self):
        # Load the models from the original ml-backend directory
        model_path = os.path.join(os.path.dirname(__file__), '..', 'ml-backend', 'models', 'bias_classifier.pkl')
        vectorizer_path = os.path.join(os.path.dirname(__file__), '..', 'ml-backend', 'models', 'tfidf_vectorizer.pkl')
        
        if os.path.exists(model_path) and os.path.exists(vectorizer_path):
            try:
                self.model = joblib.load(model_path)
                self.vectorizer = joblib.load(vectorizer_path)
                print("✓ Pre-trained ML models loaded successfully.")
            except Exception as e:
                print(f"⚠ Warning: Could not load ML models: {e}")

    def analyze_sentiment(self, text):
        vader_scores = self.vader_analyzer.polarity_scores(text)
        blob = TextBlob(text)
        
        positive = (vader_scores['pos'] * 0.7 + max(0, blob.sentiment.polarity) * 0.3)
        negative = (vader_scores['neg'] * 0.7 + max(0, -blob.sentiment.polarity) * 0.3)
        neutral = vader_scores['neu']

        total = positive + negative + neutral
        if total > 0:
            positive /= total
            negative /= total
            neutral /= total
            
        return {
            'positiveScore': round(positive, 3),
            'negativeScore': round(negative, 3),
            'neutralScore': round(neutral, 3),
            'compound': vader_scores['compound']
        }

    def detect_biases(self, text):
        biases = []
        sentences = sent_tokenize(text)
        
        for sentence in sentences:
            if len(sentence.strip()) < 10: continue
            
            # ML detection
            if self.model and self.vectorizer:
                try:
                    sentence_tfidf = self.vectorizer.transform([sentence])
                    prediction = self.model.predict(sentence_tfidf)[0]
                    confidence = float(max(self.model.predict_proba(sentence_tfidf)[0]))
                    
                    if prediction != 'none' and confidence > 0.4:
                        biases.append({
                            'type': prediction.title() + ' Bias',
                            'evidence': sentence.strip(),
                            'confidence': round(confidence, 3)
                        })
                        continue
                except: pass

            # Fallback Rule-based detection
            lower_sentence = sentence.lower()
            for btype, patterns in self.bias_patterns.items():
                for p in patterns:
                    if re.search(p, lower_sentence):
                        biases.append({
                            'type': btype.title() + ' Bias (Rule)',
                            'evidence': sentence.strip(),
                            'confidence': 0.75
                        })
                        break
        return biases

    def process_realtime_text(self, text: str):
        """Ultra-fast processing optimized for WebSockets"""
        sentiment = self.analyze_sentiment(text)
        biases = self.detect_biases(text)
        
        # Determine current primary bias risk
        risk_level = "low"
        if len(biases) > 0: risk_level = "medium"
        if len(biases) > 1 or sentiment['compound'] <= -0.5: risk_level = "high"
        
        return {
            "text_length": len(text),
            "sentiment": sentiment,
            "detected_biases": biases,
            "risk_level": risk_level,
            "suggestions": self.generate_suggestions(biases)
        }
        
    def generate_suggestions(self, biases):
        # AI "Neutral Rewrite" suggestions based on detected biases
        suggestions = []
        for bias in biases:
            if 'Confirmation' in bias['type']:
                suggestions.append(f"Consider modifying absolutist language in: '{bias['evidence']}' to be more objective.")
            if 'Negativity' in bias['type']:
                suggestions.append(f"The phrasing '{bias['evidence']}' carries extreme negative sentiment. Consider a neutral reframe.")
        return suggestions
