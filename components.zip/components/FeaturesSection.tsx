import React from 'react';
import { motion } from 'framer-motion';
import { Brain, Zap, TrendingUp, Shield, Sparkles, Target } from 'lucide-react';

const FeaturesSection: React.FC = () => {
  const features = [
    {
      icon: <Brain className="w-8 h-8" />,
      title: "Dual AI Models",
      description: "Leverage both Gemini and DeepSeek AI for comprehensive bias detection with cross-validation",
      color: "from-primary-500 to-primary-600"
    },
    {
      icon: <Sparkles className="w-8 h-8" />,
      title: "Real-time Analysis",
      description: "Get instant insights with streaming analysis and live reasoning process visualization",
      color: "from-secondary-500 to-secondary-600"
    },
    {
      icon: <TrendingUp className="w-8 h-8" />,
      title: "Advanced Metrics",
      description: "Comprehensive sentiment analysis, topic modeling, and association rule mining",
      color: "from-pink-500 to-pink-600"
    },
    {
      icon: <Target className="w-8 h-8" />,
      title: "Bias Detection",
      description: "Identify confirmation bias, negativity bias, and other cognitive distortions",
      color: "from-amber-500 to-amber-600"
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Data Privacy",
      description: "All analysis happens securely with no data storage or third-party sharing",
      color: "from-emerald-500 to-emerald-600"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Export Reports",
      description: "Download comprehensive PDF reports and visualizations for your records",
      color: "from-blue-500 to-blue-600"
    }
  ];

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            Powerful Features
          </h2>
          <p className="text-xl text-slate-600 max-w-2xl mx-auto">
            Advanced AI-powered tools to detect and analyze cognitive biases in online discussions
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -8, scale: 1.02 }}
              className="bg-white rounded-2xl p-6 shadow-lg border border-slate-100 hover:shadow-xl transition-all duration-300"
            >
              <div className={`inline-flex p-3 rounded-xl bg-gradient-to-br ${feature.color} shadow-lg mb-4`}>
                <div className="text-white">
                  {feature.icon}
                </div>
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">{feature.title}</h3>
              <p className="text-slate-600 leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
