import React, { useState } from 'react';
import { ReasoningStep } from '../types';
import { Brain, ChevronDown, ChevronUp, Clock } from 'lucide-react';

interface ReasoningDisplayProps {
  reasoning: ReasoningStep[];
  isStreaming?: boolean;
}

const ReasoningDisplay: React.FC<ReasoningDisplayProps> = ({ reasoning, isStreaming = false }) => {
  const [isExpanded, setIsExpanded] = useState(true);

  if (!reasoning || reasoning.length === 0) {
    return null;
  }

  return (
    <div className="bg-gradient-to-br from-violet-50 to-purple-50 rounded-2xl border border-violet-200 overflow-hidden shadow-lg shadow-violet-100/50">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full px-6 py-4 flex items-center justify-between hover:bg-violet-100/50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-violet-100 rounded-lg">
            <Brain className="w-5 h-5 text-violet-600" />
          </div>
          <div className="text-left">
            <h3 className="text-lg font-bold text-violet-900">
              DeepSeek Reasoning Process
            </h3>
            <p className="text-xs text-violet-600">
              {isStreaming ? 'Thinking in progress...' : `${reasoning.length} reasoning steps`}
            </p>
          </div>
        </div>
        {isExpanded ? (
          <ChevronUp className="w-5 h-5 text-violet-600" />
        ) : (
          <ChevronDown className="w-5 h-5 text-violet-600" />
        )}
      </button>

      {isExpanded && (
        <div className="px-6 pb-6 space-y-3 max-h-96 overflow-y-auto">
          {reasoning.map((step, index) => (
            <div
              key={step.timestamp}
              className="bg-white rounded-lg p-4 border border-violet-100 shadow-sm"
            >
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-violet-100 flex items-center justify-center">
                  <span className="text-xs font-bold text-violet-600">
                    {index + 1}
                  </span>
                </div>
                <div className="flex-1">
                  <p className="text-sm text-slate-700 leading-relaxed">
                    {step.content}
                  </p>
                </div>
              </div>
            </div>
          ))}
          {isStreaming && (
            <div className="flex items-center gap-2 text-violet-600 text-sm">
              <Clock className="w-4 h-4 animate-pulse" />
              <span className="animate-pulse">Analyzing...</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ReasoningDisplay;
